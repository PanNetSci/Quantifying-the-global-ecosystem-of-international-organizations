import pandas as pd



'''加载数据集'''



class loader:
    node_dict = {}

    # 1、设置初始化方法，实例化类时需要传入目标数据的path
    def __init__(self, matrix_path):
        self.matrix_path = matrix_path

    # 2、读取数据集中的数据，将结果存储在类中
    def load(self):
        #读取数据
        self.hyper_matrix = pd.read_csv(self.matrix_path, index_col=False, header=None, sep=' ')  #读取指定路径的文件，不指定列名和索引列，为节点与超边的邻接矩阵
        self.node_num = self.hyper_matrix.shape[0]  #数据中涉及的节点的数量,即国家的数量193
        self.hp_edge_num = self.hyper_matrix.shape[1]  #数据中涉及的组织的数量


