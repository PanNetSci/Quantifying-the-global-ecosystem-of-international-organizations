import pandas as pd
import numpy as np
import os
from Loader import loader
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl
from matplotlib.colors import LogNorm, LinearSegmentedColormap
import networkx as nx
import plotly.graph_objects as go
import matplotlib.patches as patches



# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 24





# 1至97个主题到领域的划分,有个别主题没有划分到这10个领域中 【有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0】
field1 = [21, 38, 52, 53, 54, 57, 68, 73, 88]
field2 = [2, 8, 11, 12, 14, 18, 20, 28, 32, 40, 47, 50, 51, 67, 69, 70, 77]
field3 = [1, 4, 7, 27, 42, 46, 64]
field4 = [9, 24, 33, 35, 41, 43, 44, 59, 61, 71, 89]
field5 = [15, 39, 48, 58, 66, 80, 81, 82, 83, 84, 87, 90, 91, 92, 93, 94, 95, 96, 97]
field6 = [3, 6, 17, 23, 36, 55, 60, 78, 79, 85, 86]
field7 = [13, 16, 19, 29, 31, 37, 45, 56, 72, 75, 76]
field8 = [10, 26, 30, 49, 63]
field9 = [62, 74]
field10 =[5, 25, 34]



# 1、加载数据，转为国家与组织的关联矩阵------------------------------------------------------------------------------------------------------------
data = pd.read_json('org.json', encoding="utf-8")
subject = data['主题序号']
edgeNum = data.shape[0] #组织的数量
field = []


for i in range(edgeNum):
    if subject[i] != None:  #第146个组织Bonsucro没有主题
        numbers = subject[i].split() #以空格分隔
        numbers_list = [int(num) for num in numbers] #转为整型列表
        subject_index = [index+1 for index, value in enumerate(numbers_list) if value != 0]  #该组织所属主题的序号1至97
        field_index = [] #由主题序号进一步判断该组织所属领域
        if bool(set(subject_index) & set(field1)): #两个集合有交集True
            field_index.extend([1])
        if bool(set(subject_index) & set(field2)):
            field_index.extend([2])
        if bool(set(subject_index) & set(field3)):
            field_index.extend([3])
        if bool(set(subject_index) & set(field4)):
            field_index.extend([4])
        if bool(set(subject_index) & set(field5)):
            field_index.extend([5])
        if bool(set(subject_index) & set(field6)):
            field_index.extend([6])
        if bool(set(subject_index) & set(field7)):
            field_index.extend([7])
        if bool(set(subject_index) & set(field8)):
            field_index.extend([8])
        if bool(set(subject_index) & set(field9)):
            field_index.extend([9])
        if bool(set(subject_index) & set(field10)):
            field_index.extend([10])
        # 因为有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0，后续不进行统计了
        if field_index != []:
            field.append(field_index)
        else:
            field.append([0])
    else:
        field.append([0])

data['field'] = field  # 添加领域信息





# 2、统计每个国家参与每个领域的组织数量---------------------------------------------------------------------------------------------------------------------------
num_countries = 193 # 国家数量
num_fields = 10  # 领域数量

country_field_matrix = np.zeros((num_countries, num_fields), dtype=int)  # 193 行 × 10 列

for idx, row in data.iterrows():  #迭代data的每一行
    country = row['Nation_Member_Index']  # 获取组织包含国家的字符串
    fields = row['field']  # 获取组织所属领域的列表

    # 将字符串转为国家下标索引
    if country.strip():  # 检查字符串是否为空
        country_index = list(map(int, country.split()))
    else:
        country_index = []  # 如果为空，设置为空列表

    # 更新矩阵
    for field in fields:
        if field != 0:  # 忽略未划分到领域的组织
            country_field_matrix[country_index, field - 1] += 1  # 领域从 1 开始，矩阵索引从 0 开始



# 3、每个国家自身各领域数量进行归一化---------------------------------------------------------------------------------------------------------------------------
# 计算每个国家的组织总数（按行求和）
row_sums = country_field_matrix.sum(axis=1, keepdims=True)  # shape: (193, 1)

# 避免除以零（若某国无任何组织参与）
row_sums[row_sums == 0] = 1  # 将0替换为1，避免NaN

# 行归一化
country_field_normalized = country_field_matrix / row_sums  # shape: (193, 10)





# 4.1、全球基准向量一：各国的在每个领域上的平均值---------------------------------------------------------------------------------------------------------------------------
global_benchmark_mean = country_field_normalized.mean(axis=0)  # axis=0 表示按列计算
print("全球基准向量（各国归一化的平均值）:", global_benchmark_mean)


# 4.2、全球基准向量二：全球组织在各领域上数量的归一化---------------------------------------------------------------------------------------------------------------------------
# 计算各领域全球组织总数（按列求和）
global_field_counts = country_field_matrix.sum(axis=0)  # shape: (10,)
# 计算全球组织总数（所有领域之和）
total_global_organizations = global_field_counts.sum()  # 标量
# 全局归一化
global_benchmark_normalized = global_field_counts / total_global_organizations
print("全球基准向量（全球组织数量归一化）:", global_benchmark_normalized)




# 4.3、计算相对强度
relative_strength = country_field_normalized / global_benchmark_normalized   #或者global_benchmark_normalized    global_benchmark_mean




#4.3.1读取国家名称列表，按照所有领域总强度降序排列
# with open('Nations_Dictionary.txt', 'r', encoding='utf-8') as f:
#     original_countries = [line.strip() for line in f if line.strip()]
#
# #假设已计算好的排序索引 (示例)
# sorted_ = np.argsort(relative_strength.sum(axis=1))[::-1]  # 实际使用时取消注释
#
# #按排序索引重新排列国家
# sorted_countries = [original_countries[i] for i in sorted_]
#
# #保存到新文件
# with open('Sorted_Nations.txt', 'w', encoding='utf-8') as f:
#     f.write("\n".join(sorted_countries))





# #4.3.2读取国家的简称列表，按照所有领域总强度降序排列
# # 读取国家简称Excel文件
# country_abbr_df = pd.read_excel('国家简称.xlsx', sheet_name='国家的简称')
# # 创建国家全称到简称的映射字典（使用"我们的称呼"列作为全称）
# country_abbr_dict = dict(zip(country_abbr_df['我们的称呼'], country_abbr_df['简称']))
# # 读取原始国家全称列表
# with open('Nations_Dictionary.txt', 'r', encoding='utf-8') as f:
#     original_countries = [line.strip() for line in f if line.strip()]
# # 将全称转换为简称（如果找不到匹配则保留原名称）
# country_abbreviations = [country_abbr_dict.get(name, name) for name in original_countries]
# # 使用之前计算的relative_strength进行排序（假设已计算好）
# sorted_ = np.argsort(relative_strength.sum(axis=1))[::-1]  # 降序排列
# # 按排序结果重新排列国家简称
# sorted_countries_abbr = [country_abbreviations[i] for i in sorted_]
# # 保存排序后的国家简称到新文件
# with open('Sorted_Nations_Abbr.txt', 'w', encoding='utf-8') as f:
#     f.write("\n".join(sorted_countries_abbr))





#4.3.3 按照每个领域（列）对 relative_strength 进行降序排序，并输出每个领域排序结果
# field_labels 是领域标签
field_labels = ['TE', 'SP', 'RC', 'ER', 'RE', 'HW', 'ED', 'DS', 'SE', 'AD']

# 读取 Excel 文件
df = pd.read_excel('国家简称.xlsx', sheet_name='国家的简称')
# 获取第5列（假设是"简称"列），并清理每个值
country_abbr = [str(code).strip() for code in df.iloc[:, 4]]  # 或者 df['简称']

# 创建DataFrame存储结果
results = pd.DataFrame()
# 对每个领域进行处理
for col in range(relative_strength.shape[1]):
    # 获取当前领域的国家索引(降序)
    sorted_indices = np.argsort(-relative_strength[:, col])
    # 添加国家简称列
    results[f"{field_labels[col]}_国家"] = [country_abbr[i] for i in sorted_indices]
    # 添加对应强度值列
    results[f"{field_labels[col]}_强度"] = [f"{relative_strength[i, col]:.3f}" for i in sorted_indices]
# 计算综合排名（所有领域强度加和）
total_strength = relative_strength.sum(axis=1)
overall_ranking = np.argsort(-total_strength)
# 添加综合排名列
results["综合排名_国家"] = [country_abbr[i] for i in overall_ranking]
results["综合排名_强度"] = [f"{total_strength[i]:.3f}" for i in overall_ranking]

# 保存到Excel文件
results.to_excel("Country_Rankings_by_Field.xlsx", index=False, sheet_name="排名")













# 5、可视化------------------------------------------------------------------------------------------------------------------------------------------------------



























# 5.1 通过网络可视化------------------------------------------------------------------------------------------------------------------------------------------------------
# # 设定阈值
# significant_mask = relative_strength > 1
# significant_pairs = np.argwhere(significant_mask)  # 获取行列索引，返回输入数组中所有 True 值的坐标
#
# #构建图
# G = nx.Graph()
#
# country_labels = [f"C{i}" for i in range(193)]  # 替换为实际国家名
# field_labels = ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']      # 替换为实际领域名
#
# # 添加节点（国家和领域）
# G.add_nodes_from(country_labels, bipartite=0)  # 国家节点
# G.add_nodes_from(field_labels, bipartite=1)    # 领域节点
#
# # 添加边（显著关联）
# for country_idx, field_idx in significant_pairs:
#     strength = relative_strength[country_idx, field_idx]
#     G.add_edge(country_labels[country_idx], field_labels[field_idx], weight=strength)
#
# # 绘制网络
# pos = nx.spring_layout(G, k=0.5)  # 节点的布局位，k越大节点间距越大，布局越松散
# nx.draw_networkx_nodes(G, pos, nodelist=country_labels, node_color='lightblue', label='Countries')
# nx.draw_networkx_nodes(G, pos, nodelist=field_labels, node_color='orange', label='Fields')
# nx.draw_networkx_edges(G, pos, width=[d['weight']*0.5 for (u,v,d) in G.edges(data=True)])
# nx.draw_networkx_labels(G, pos)
# plt.legend()
# plt.title("Significant Country-Field Associations")
# plt.show()









# 5.2 通过热力图可视化------------------------------------------------------------------------------------------------------------------------------------------------------


#5.2.1 原始矩阵直接可视化--------------------------------------------------------------------------------------------------------------------------

# # 设置国家标签和领域标签（示例）
# country_labels = [f"C{i}" for i in range(193)]  # 替换为实际国家名
# field_labels = ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']      # 替换为实际领域名
#
# # 绘制热力图
# plt.figure(figsize=(15, 20))  # 调整画布大小
# heatmap = sns.heatmap(
#     relative_strength,
#     cmap="coolwarm",          # 颜色映射：红-蓝
#     center=1,                 # 中性值（1表示与基准持平）
#     xticklabels=field_labels,  # X轴标签
#     yticklabels=country_labels, # Y轴标签
#     linewidths=0.5,           # 单元格边框线宽
#     linecolor="gray",         # 边框颜色
#     annot=False,              # 是否显示数值（数据量大时建议关闭）
#     cbar_kws={"label": "Relative Strength"}  # 颜色条标签
# )
#
# # 优化标签显示
# plt.xticks(rotation=45, ha="right")  # X轴标签旋转45度
# plt.yticks(fontsize=8)               # Y轴标签字体大小
# plt.xlabel("Fields")
# plt.ylabel("Countries")
# plt.title("Country-Field Relative Strength (vs Global Benchmark)")
# plt.tight_layout()  # 自动调整布局
# plt.show()






#5.2.2 按照国家加入组织的总量行排序--------------------------------------------------------------------------------------------------------------------------
# # 设置国家标签和领域标签（示例）
# country_labels = [f"C{i}" for i in range(193)]  # 替换为实际国家名
# field_labels = ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']      # 替换为实际领域名
#
# # 计算每个国家的组织总数（按行求和）
# country_total_organizations = country_field_matrix.sum(axis=1)  # 形状: (193,)
#
# # 获取按组织总数从大到小排序的国家索引
# sorted_country_indices = np.argsort(country_total_organizations)[::-1]  # [::-1]表示降序
#
# # 对相对强度矩阵和国家标签按排序结果重新排列
# sorted_relative_strength = relative_strength[sorted_country_indices]
# sorted_country_labels = [country_labels[i] for i in sorted_country_indices]
#
# # 使用排序后的 sorted_relative_strength 和 sorted_country_labels 绘制热力图
# plt.figure(figsize=(15, 20))
# heatmap = sns.heatmap(
#     sorted_relative_strength,  # 使用排序后的数据
#     cmap="coolwarm",
#     center=1,
#     xticklabels=field_labels,
#     yticklabels=sorted_country_labels,  # 使用排序后的标签
#     linewidths=0.5,
#     linecolor="gray",
#     annot=False,
#     cbar_kws={"label": "Relative Strength"}
# )
#
# # 优化显示
# plt.xticks(rotation=45, ha="right")
# plt.yticks(fontsize=8)
# plt.xlabel("Fields")
# plt.ylabel("Countries (Sorted by Total Organizations)")
# plt.title("Country-Field Relative Strength (vs Global Benchmark, Sorted by Country Size)")
# plt.tight_layout()
# plt.show()






#5.2.3 按照国家相对强度的行和排序--------------------------------------------------------------------------------------------------------------------------

# 计算每个国家的相对强度行和
country_relative_strength_sum = relative_strength.sum(axis=1)  # 形状: (193,)

#  按行和降序排序
sorted_indices = np.argsort(country_relative_strength_sum)[::-1]  # 降序索引
sorted_relative_strength = relative_strength[sorted_indices]


#读取国家名称列表
with open('Nations_Dictionary.txt', 'r', encoding='utf-8') as f:
    original_countries = [line.strip() for line in f if line.strip()]
#按排序索引重新排列国家
sorted_country_labels  = [original_countries[i] for i in sorted_indices]
# 设置国家标签和领域标签（示例）
field_labels = ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']      # 替换为实际领域名




# 绘制热力图
plt.figure(figsize=(10, 15))
sns.heatmap(
    sorted_relative_strength,
    cmap="coolwarm",
    center=1,
    xticklabels=field_labels,
    yticklabels=sorted_country_labels,
    linewidths=0.5,
    linecolor="gray",
    annot=False,
    cbar_kws={"label": "Relative Strength"},
)
plt.title("Country-Field Relative Strength (Sorted by Row Sum of Relative Strength)", fontsize=24)
plt.ylabel("Countries (Sorted by Σ(Relative Strength))", fontsize=24)
plt.xticks(fontsize=24)
plt.yticks(fontsize=5)
plt.tight_layout()
plt.show()








# 5.3.1、 按照国家相对强度的行和排序、领域强度降序，流向图--------------------------------------------------------------------------------------------------------------------------
# # 1. 准备排序后的节点标签（国家按行和降序，领域按全球参与度降序）
# country_labels = [f"C{i}" for i in range(num_countries)]  # 替换为实际国家名
# field_labels = ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']  # 替换为实际领域名
# # 计算排序索引
# country_order = np.argsort(relative_strength.sum(axis=1))[::-1]  # 国家按行和降序
# sorted_country_labels = [country_labels[i] for i in country_order]
#
# # 按领域参与度排序
# # field_order = np.argsort(global_benchmark_mean)[::-1]
# # sorted_field_labels = [field_labels[i] for i in field_order]
#
# # 同步排序国家和领域
# # sorted_relative_strength = relative_strength[country_order][:, field_order]
# sorted_relative_strength = relative_strength[country_order]
#
#
#
# # 2. 构建节点和链接数据
# # all_nodes = sorted_country_labels + sorted_field_labels
# all_nodes = sorted_country_labels + field_labels
# sources = []
# targets = []
# values = []
# strength_threshold = 0  # 只显示显著关联
#
# for country_idx in range(num_countries):
#     for field_idx in range(num_fields):
#         strength = sorted_relative_strength[country_idx, field_idx]
#         if strength >= strength_threshold:
#             sources.append(country_idx)  # 国家节点索引（已排序）
#             targets.append(num_countries + field_idx)  # 领域节点索引（偏移量）
#             values.append(strength)
#
# # 3. 颜色设置（国家蓝色，领域橙色）
# node_colors = (
#     ['#1f77b4'] * num_countries +  # 国家节点
#     ['#ff7f0e'] * num_fields       # 领域节点
# )
#
# # 4. 创建流向图
# fig = go.Figure(go.Sankey(
#
#     arrangement="snap",
#     node=dict(
#         pad=20,
#         thickness=15,
#         line=dict(color="black", width=0.5),
#         label=all_nodes,
#         color=node_colors,
#         hovertemplate='%{label}<extra></extra>'
#     ),
#     link=dict(
#         source=sources,
#         target=targets,
#         value=values,
#         hovertemplate='%{source.label} → %{target.label}<br>强度: %{value:.2f}<extra></extra>',
#         color='rgba(180, 180, 180, 0.4)'
#     )
# ))
#
# # 5. 优化布局
# fig.update_layout(
#     title_text=f"国家-领域关联（国家按综合强度降序，领域按全球参与度降序）",
#     font_size=10,
#     height=900,
#     margin=dict(l=50, r=50, b=50, t=50)
# )
#
# fig.show()





# # 5.3.2、 按照国家相对强度的行和排序、领域强度降序，流向图--------------------------------------------------------------------------------------------------------------------------
# # 1. 准备排序后的节点标签（国家按行和降序，领域按全球参与度降序）
# field_labels = ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']  # 替换为实际领域名
# # 计算排序索引
# country_order = np.argsort(relative_strength.sum(axis=1))[::-1]  # 国家按行和降序
# sorted_country_labels = sorted_countries
#
# # 按领域参与度排序
# # field_order = np.argsort(global_benchmark_mean)[::-1]
# # sorted_field_labels = [field_labels[i] for i in field_order]
#
# # 同步排序国家和领域
# # sorted_relative_strength = relative_strength[country_order][:, field_order]
# sorted_relative_strength = relative_strength[country_order]
#
#
#
# # 2. 构建节点和链接数据
# # all_nodes = sorted_country_labels + sorted_field_labels
# all_nodes = sorted_country_labels + field_labels
# sources = []
# targets = []
# values = []
# strength_threshold = 1  # 只显示显著关联
#
# for country_idx in range(num_countries):
#     for field_idx in range(num_fields):
#         strength = sorted_relative_strength[country_idx, field_idx]
#         if strength > strength_threshold:
#             sources.append(country_idx)  # 国家节点索引（已排序）
#             targets.append(num_countries + field_idx)  # 领域节点索引（偏移量）
#             values.append(strength)
#
#
#
# # 3. 颜色设置
# # 领域颜色列表
# field_colors = [
#     '#82B0D2', '#E25C5C', '#FFB061', '#BECFC9', '#C1DE9C',
#     '#E7DAD2', '#BEB8DC', '#999999', '#F3D266', '#F6CAE5'
# ]
#
#
#
# # 节点位置：国家在上，领域在下
# node_x = np.concatenate([np.linspace(0.1, 0.9, num_countries),  # 国家节点
#                          np.linspace(0.1, 0.9, num_fields)])    # 领域节点
# node_y = np.concatenate([np.ones(num_countries) * 0.6,         # 国家节点Y坐标
#                          np.ones(num_fields) * 0.2])            # 领域节点Y坐标
#
#
# # 4. 创建流向图
# fig = go.Figure(go.Sankey(
#     arrangement="freeform",
#     node=dict(
#         pad=20,
#         thickness=15,
#         line=dict(color="black", width=0.5),
#         label=all_nodes,
#         color=['#1f77b4']*num_countries + field_colors,
#         # 节点位置设置（领域节点按总强度比例分布）
#         x=node_x,
#         y=node_y
#     ),
#     link=dict(
#         source=sources,
#         target=targets,
#         value=values,
#         color=[field_colors[t - num_countries] for t in targets],
#         hovertemplate='%{source.label} → %{target.label}<br>强度: %{value:.2f}<extra></extra>'
#     )
# ))
#
# # 5. 优化布局
# fig.update_layout(
#     title_text=f"国家-领域关联",
#     font_size=10,
#     height=900,
#     margin=dict(l=50, r=50, b=50, t=50)
# )
#
# fig.show()

