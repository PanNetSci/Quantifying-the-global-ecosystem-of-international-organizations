import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import matplotlib as mpl
from matplotlib.ticker import FixedLocator, FormatStrFormatter


# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')




mpl.rcParams['font.family'] = 'Times New Roman'


# 读取Excel文件
df = pd.read_excel('Country_Rankings_by_Field（与全球自身归一化相比）.xlsx', sheet_name='排名')

# 获取所有领域名称（从列名中提取）
fields = []
for col in df.columns:
    if '_国家' in col and col != '综合排名_国家':
        fields.append(col.replace('_国家', ''))



# 为每个领域创建散点图
for field in fields:
    # 提取国家和强度数据
    countries = df[f'{field}_国家']
    strengths = df[f'{field}_强度']

    # 创建图表
    plt.figure(figsize=(31.5, 8))

    # 计算对称的颜色映射范围（使1.0居中）
    # max_val = max(abs(strengths - 1.0).max(), 0.1)  # 确保足够的颜色范围
    # norm = mpl.colors.TwoSlopeNorm(vmin=1-max_val, vcenter=1.0, vmax=1+max_val)
    # norm = mpl.colors.TwoSlopeNorm(vmin=strengths.min(), vcenter=1.0, vmax=strengths.max())
    # cbar_ticks = np.linspace(strengths.min(), strengths.max(), 5)  # 5个等间距刻度

    # 计算颜色映射范围（确保1.0居中）
    vmin = strengths.min()
    vmax = strengths.max()


    # 创建标准化映射
    norm = mpl.colors.TwoSlopeNorm(vmin=vmin, vcenter=1.0, vmax=vmax)


    # 生成5个等间距刻度（包含最小、1.0和最大值）
    cbar_ticks = [vmin, (vmin + 1.0) / 2, 1.0, (1.0 + vmax) / 2, vmax]


    # 绘制散点图，根据强度值设置颜色和大小
    scatter = plt.scatter(
        x=countries,
        y=strengths,
        c=strengths,  # 颜色映射到强度值
        cmap='coolwarm',
        norm=norm,  # 使用标准化映射
        s=strengths * 280,  # 点大小映射到强度值
        alpha=0.9,
        edgecolors='w',
        linewidth=0.6
    )


    # 添加颜色条
    cbar = plt.colorbar(scatter, pad=0.03)
    cbar.set_ticks(cbar_ticks)  # 设置固定刻度
    cbar.ax.tick_params(labelsize=38)  # 颜色条字体大小
    cbar.ax.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))  # 两位小数


    # # 标记强度值高于1.0的点
    # for i, (country, strength) in enumerate(zip(countries, strengths)):
    #     if strength > 1.0:
    #         plt.text(
    #             country, strength + 0.02,
    #             f'{country}\n{strength:.2f}',
    #             # f'{strength:.2f}',
    #             ha='center', va='bottom',
    #             fontsize=20,
    #             bbox=dict(facecolor='white', alpha=0.7, edgecolor='none', pad=1)
    #         )


    # 设置X轴标签（每隔两个显示一个）
    visible_ticks = range(0, len(countries), 3)  # 0,3,6,9...
    plt.xticks(
        ticks=visible_ticks,
        labels=[countries[i] for i in visible_ticks],
        rotation=90,
        fontsize=28
    )

    # 设置图表标题和标签
    # plt.xlabel('Country', fontsize=42)
    plt.xlabel('Country', fontsize=42)
    plt.ylabel('Ratio', fontsize=42)
    plt.yticks(fontsize=38)
    plt.xlim(-2, len(countries)+1)  # 强制X轴范围匹配数据点数量
    plt.axhline(y=1.0, color='#a6a6a6', linestyle='--', linewidth=2.0, zorder=-1)  # 基准线

    # 调整布局
    plt.tight_layout()

    # 保存图表
    plt.savefig(f'{field}_领域排名_散点图.png', dpi=330, bbox_inches='tight')
    plt.close()

print(f"已生成{len(fields)}个领域的散点图。")