import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
import statsmodels.api as sm
import matplotlib as mpl 


# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')
mpl.rcParams['font.family'] = 'Times New Roman' 



data = pd.read_excel('Data.xlsx', index_col = 0)
df_countries_name = pd.read_csv('国家的简称.csv', encoding='GBK')
countries_name = list(df_countries_name['简称'])


colors = ['#F8B072', '#EDE277', '#9ED2E2', '#CFA8D0', '#B7DBBE', '#D67474']


#六个大洲名称
continent_name= ["Africa", "Asia", "Europe", "North America", "Oceania", "South America"]


# 图像大小
plt.figure(figsize=(19, 7))

need_contries = ['USA', 'FRA','GBR','BEL','DEU','ITA','AUT','CAN','ESP',\
                 'HUN','LBY','MRT','GMB','SWZ','MLT','CUB','HTI','GIN','MMR',\
                     'KHM','IRQ','SSD','PKR','LIE','SUR','CAE','KNA','BRN','GEO',\
                         'ATG','BDI','MNG','BLR','MOZ','OAT','UZB','WSM','COG','BWA',\
                             'LCA','HND','GTM','ISL','EST','BOL','LVA','HRV','UKR','BEN',\
                                 'SRB','SVK','ROU','PAN','UGA','TTO','CRI','COL','URY','NGA',\
                                     'ISR','SAU','IRL','GRC','CHN','BRA','RUS','SGP','FIN','NOR',\
                                         'DNK','JPN','ARG','MEX','ZAF','KOR','CHN','AUS','IND']



# 1、绘制散点图
for i in range(1,7):
    df_bases = data[data['Continent'] == i]
    plt.scatter(df_bases['Number'], df_bases['Scale'], color=colors[i-1], label=continent_name[i-1], s=50, alpha=1)

    # 在每个点的附近显示国家名称
    selected_countries = [countries_name[idx] for idx in df_bases.index]
    for (num, scale, country) in zip(df_bases['Number'], df_bases['Scale'], selected_countries):
        if country in need_contries:
            plt.annotate(country, (num, scale), textcoords="offset points", xytext=(0, 2.5), ha='center', va='bottom', fontsize=16)   # (num, scale)标签的坐标位置，xytext=(0, 5)标签的相对位置
    
        
    # break

# 2、平均规模
# 画一条横线：当前所有组织的平均规模
# ave_scale = sum(data['Nation_Member_Number']) / edgeNum
# plt.plot(np.linspace(0.9, 2600, 2600), (np.ones_like(np.linspace(0.9, 2600, 2600)) * ave_scale), linestyle='--', color='black', linewidth=0.8, zorder=-1)
# 在图上标注值
# plt.text(2400, ave_scale, f' Average Scale: {ave_scale:.2f}', va='center', ha='right', backgroundcolor='white', fontsize=10)   #文本框背景透明bbox=dict(facecolor='none', edgecolor='none')

# 3、拟合所有数据的直线
x_data_all = np.array(data['Number'])
y_data_all = np.array(data['Scale'])
mask = np.nonzero(x_data_all)
x_fit = np.log10(x_data_all[mask])
y_fit = y_data_all[mask]

X = sm.add_constant(x_fit)
model = sm.OLS(y_fit, X).fit()

x_plot = np.linspace(x_data_all[mask].min(), x_data_all[mask].max(), 100)
X_plot = sm.add_constant(np.log10(x_plot))
prediction = model.get_prediction(X_plot)  
prediction_summary_frame = prediction.summary_frame()

plt.plot(x_plot, prediction_summary_frame['mean'], color='#D67474', label='Regression line')  
  
# 绘制预测区间  
plt.fill_between(x_plot,   
                  prediction_summary_frame['mean_ci_lower'],   
                  prediction_summary_frame['mean_ci_upper'],   
                  color='#D67474', alpha=0.3, label='95% Prediction')   #Prediction interval, PI
# 标注相关性系数
c1 = np.corrcoef(x_fit, y_fit)[0, 1]
plt.text(0.87, 0.85, 'r = %.3f'%c1, transform=plt.gca().transAxes, fontsize=25,
         bbox=dict(facecolor='white', alpha=1, edgecolor='none', boxstyle='round')
         )

plt.xscale('log')
plt.xlabel('Number', fontsize = 36)
plt.ylabel('Average scale', fontsize = 36)
plt.xticks(fontsize=32)
plt.yticks(fontsize=32)


# 在 plt.legend() 调用之前获取当前的 handles 和 labels
handles, labels = plt.gca().get_legend_handles_labels()

# 交换第四个和第五个条目
handles[3], handles[4] = handles[4], handles[3]
labels[3], labels[4] = labels[4], labels[3]

# 使用修改后的 handles 和 labels 创建图例
plt.legend(
    handles=handles,
    labels=labels,
    bbox_to_anchor=(0.995, 0.01),
    loc='lower right',
    borderaxespad=0.,
    handlelength=1.5,  # 减小线条长度
    handletextpad=0.6,  # 调整文字与线条的间距
    frameon=True,  # 不去掉图例边框
    ncol=2,  # 设置10列使所有图例项排成一行
    fontsize=19.5,  # 可选：调整字体大小以适应水平排列
    columnspacing=1  # 减小列之间的间隔，默认是2.0
)



plt.savefig('Main1.jpg', dpi = 330, bbox_inches = 'tight')

plt.show()