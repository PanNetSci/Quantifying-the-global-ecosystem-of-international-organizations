import matplotlib.pyplot as plt
import pandas as pd
import scipy.stats as stats
import matplotlib as mpl 

mpl.rcParams['font.family'] = 'Times New Roman'  # 注意：这可能在某些系统上不起作用  
mpl.rcParams['font.size'] = 15

data = pd.read_excel('2-国家参与各主题组织数量及平均规模.xlsx')
# 创建一个2行5列的画布
fig, axs = plt.subplots(2, 5, figsize=(15, 6))
plt.subplots_adjust(wspace = 0.43, hspace = 0.55)


field_labels =  ['Technology and Engineering', 
               'Society and Policy', 
               'Religion and Culture', 
               'Education and Research', 
               'Resource and Environment', 
               'Health and Wellbeing', 
               'Economy and Development', 
               'Defence and Security', 
               'Sport and Entertainment ', 
               'Art and Design']

field_labels =  ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']

color_list = [  
'#82B0D2',
'#E25C5C',
'#FFB061',
'#BECFC9',
'#C1DE9C',
'#E7DAD2',
'#BEB8DC',
'#999999',
'#F3D266',
'#F6CAE5',
]

# 在各个子图上绘制散点图
for i in range(10):
    x = i // 5
    y = i - 5*x
    
    data_x = data.iloc[:, i]
    data_y = data.iloc[:, i+10]
    correlation, p_value = stats.pearsonr(data_x, data_y)
    correlation = round(correlation, 3)
    axs[x, y].scatter(data_x, data_y, s = 2, color = color_list[i])
    x_loc = 0.9
    y_loc = 0.9
    axs[x, y].text(max(data_x)*x_loc, max(data_y)*y_loc, 'r = %s'%correlation, ha='right', va='top',\
                   bbox={'facecolor': 'white', #填充色
                                  'edgecolor':'black',#外框色
                                   'alpha': 1, #框透明度
                                   'pad': 5,#本文与框周围距离 
                                  })
    
    axs[x, y].set_title(field_labels[i])
    axs[x, y].set_xlabel('Number')
    axs[x, y].set_ylabel('Scale')
    
# 调整子图之间的间距
# plt.tight_layout()
# 显示图形
plt.savefig('10个领域容纳度散点图.jpg', dpi = 600, bbox_inches = 'tight')