import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import matplotlib.colors as colors
from matplotlib.cm import ScalarMappable
import matplotlib as mpl


# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14






# 读取Excel文件
df = pd.read_excel('4 97领域与零模型比较.xlsx', header=None)


# 提取数据部分
data = df.iloc[1:98, 1:98].values.astype(float)


# 计算每个节点的总强度并排序
node_strengths = np.sum(data, axis=1)
sorted_indices = np.argsort(node_strengths)[::-1]  # 从高到低排序的索引


# 创建二分图
B = nx.Graph()


# 添加两类节点（按强度排序）
left_nodes = [f"L{i}" for i in sorted_indices]  # 左侧节点（已排序）
right_nodes = [f"R{i}" for i in sorted_indices]  # 右侧节点（相同顺序）
B.add_nodes_from(left_nodes, bipartite=0)      # 第一组
B.add_nodes_from(right_nodes, bipartite=1)     # 第二组


# 标准化节点大小
max_strength = np.max(node_strengths)
node_sizes = node_strengths / max_strength * 200  # 归一化并缩放


# 添加边并设置权重
threshold = np.percentile(data[data > 0], 90)  # 只显示强度前10%的边
max_edge_strength = np.max(data)




for i in range(97):
    for j in range(i+1,97):
        if data[i, j] > threshold:
            # 边的权重归一化到[1, 10]范围
            normalized_weight = 1 + 9 * (data[i, j] - threshold) / (max_edge_strength - threshold)
            # 使用排序后的索引
            # B.add_edge(f"L{sorted_indices[i]}", f"R{sorted_indices[j]}", weight=normalized_weight, strength=data[i, j])
            B.add_edge(f"L{i}", f"R{j}", weight=normalized_weight, strength=data[i, j])




# 创建二分图布局（按强度排序排列）
pos = {}
# 左侧节点垂直排列（从高到低）
pos.update((f"L{sorted_indices[i]}", (0, 96-i)) for i in range(97))  # 最高强度在顶部
# 右侧节点垂直排列（相同顺序）
pos.update((f"R{sorted_indices[i]}", (1, 96-i)) for i in range(97))


# 绘制图形
plt.figure(figsize=(10, 30), dpi=100)
ax = plt.gca()


# 绘制节点 - 左侧（蓝色）
nx.draw_networkx_nodes(
    B, pos,
    nodelist=left_nodes,
    node_size=[node_sizes[int(node[1:])] for node in left_nodes],
    node_color='#1f78b4',  # 蓝色
    alpha=0.9,
    linewidths=0.5,
    edgecolors='black',
    ax=ax
)

# 绘制节点 - 右侧（橙色）
nx.draw_networkx_nodes(
    B, pos,
    nodelist=right_nodes,
    node_size=[node_sizes[int(node[1:])] for node in right_nodes],
    node_color='#e6550d',  # 橙色
    alpha=0.9,
    linewidths=0.5,
    edgecolors='black',
    ax=ax
)


# 绘制边
edge_strengths = [B[u][v]['strength'] for u, v in B.edges()]
edge_widths = [B[u][v]['weight'] for u, v in B.edges()]


# 创建对数归一化
cmap = plt.cm.plasma

edges = nx.draw_networkx_edges(
    B, pos,
    width=edge_widths,
    edge_color=edge_strengths,
    edge_cmap=cmap,
    edge_vmin=min(edge_strengths),
    edge_vmax=max(edge_strengths),
    alpha=0.6,
    arrows=False,
    ax=ax
)

# 创建ScalarMappable对象并关联到edges
sm = ScalarMappable(norm=LogNorm(), cmap=cmap)
sm.set_array(edge_strengths)

# 添加颜色条
cbar = plt.colorbar(sm, ax=ax, label='Interaction Strength (log scale)', shrink=0.7)
cbar.ax.tick_params(labelsize=12)


# 添加标签（显示所有节点编号）
label_offset = 0.02  # 标签偏移量
for i, node in enumerate(left_nodes):
    plt.text(-label_offset, 96-i, node[1:], ha='right', va='center', fontsize=8)
for i, node in enumerate(right_nodes):
    plt.text(1+label_offset, 96-i, node[1:], ha='left', va='center', fontsize=8)


plt.xlim(-0.2, 1.2)
plt.ylim(-5, 105)  # 留出一些边距
plt.axis('off')


# 保存图像
plt.savefig('sorted_bipartite_network.png', bbox_inches='tight', dpi=300)
