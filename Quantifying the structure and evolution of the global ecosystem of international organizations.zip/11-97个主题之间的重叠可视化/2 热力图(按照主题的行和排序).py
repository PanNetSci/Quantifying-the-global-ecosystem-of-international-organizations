import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as colors
from matplotlib.patches import Rectangle
import matplotlib as mpl
from matplotlib.colors import ListedColormap



# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14




# 1至97个主题到领域的划分,一共用了90个主题。有个别主题没有划分到这10个领域中 【有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0】
field1 = [21, 38, 52, 53, 54, 57, 68, 73, 88]
field2 = [8, 11, 12, 14, 18, 20, 30, 32, 40, 47, 50, 51, 67, 69]
field3 = [1, 4, 7, 27, 42, 46, 64]
field4 = [24, 33, 35, 41, 43, 44, 59, 61, 71, 89]
field5 = [15, 39, 48, 58, 66, 80, 81, 82, 83, 84, 87, 90, 91, 92, 93, 94, 95, 96, 97]
field6 = [3, 6, 17, 23, 36, 55, 60, 78, 79, 85, 86]
field7 = [13, 16, 19, 29, 31, 37, 45, 56, 72, 75, 76]
field8 = [10, 63, 26, 30]
field9 = [62, 74]
field10 = [5, 25, 34]


# 读取Excel文件
df = pd.read_excel('4 97领域与零模型比较.xlsx', header=None)
data = df.iloc[1:98, 1:98].values.astype(float)


# 创建领域分组列表
fields = [field1, field2, field3, field4, field5, field6, field7, field8, field9, field10]
field_names = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']


# 计算每个主题的行和（强度）
node_strengths = np.sum(data, axis=1)


# 对每个领域内的主题按其行和从高到低排序
sorted_fields = []
for field in fields:
    # 获取领域内主题的索引（0-based）
    indices = [t-1 for t in field]
    # 获取这些主题的行和
    strengths = node_strengths[indices]
    # 按行和从高到低排序
    sorted_indices = [x for _, x in sorted(zip(strengths, field), reverse=True)]
    sorted_fields.append(sorted_indices)

# 创建排序后的主题列表
sorted_topics = []
for field in sorted_fields:
    sorted_topics.extend(field)


# 重新排列数据矩阵
sorted_indices = [t-1 for t in sorted_topics]  # 转换为0-based索引
sorted_data = data[sorted_indices, :][:, sorted_indices]


# 提取上三角部分（包括对角线）并将对角线设为1
upper_tri = np.triu(sorted_data, k=0)  # k=0表示包含对角线



# 计算每个领域的边界位置
field_boundaries = []
current_pos = 0
for field in fields:
    field_boundaries.append((current_pos, current_pos + len(field) - 1))
    current_pos += len(field)



# 创建热力图
plt.figure(figsize=(16, 14))
ax = plt.gca()


# 使用对数归一化
original_cmap = plt.get_cmap('OrRd')  # 获取原始颜色映射
col = original_cmap(np.linspace(0.1, 0.85, 256))  # 从原颜色映射的10%位置开始（去掉最浅的黄色）到85%位置结束（去掉最深的红色），生成256个颜色点保证平滑过渡
adjusted_cmap = ListedColormap(col)

norm = colors.LogNorm(vmin=np.min(data[data > 0]), vmax=np.max(data))

im = ax.imshow(upper_tri, cmap=adjusted_cmap, norm=norm)



# 添加颜色条
cbar = plt.colorbar(im, ax=ax, shrink=0.8)


#最后一个领域起点和终点
a,b = field_boundaries[-1]
c,d = field_boundaries[0]


# 添加领域分隔线（仅右上三角）
for i, (boundary, name) in enumerate(zip(field_boundaries, field_names)):
    start, end = boundary
    # 水平分隔线:  X轴坐标（起点和终点）    Y轴坐标（保持相同值，形成水平线
    ax.plot([start - 0.5, b + 0.5], [start - 0.5, start - 0.5], color='black', linestyle='--', linewidth=0.6)
    # 垂直分隔线
    ax.plot([end + 0.5, end + 0.5], [c - 0.5, end + 0.5], color='black', linestyle='--', linewidth=0.6)


# 添加领域内自己的分割线
for i, (boundary, name) in enumerate(zip(field_boundaries, field_names)):
    start, end = boundary
    # 水平分隔线:  X轴坐标（起点和终点）    Y轴坐标（保持相同值，形成水平线
    ax.plot([start - 0.5, end + 0.5], [start - 0.5, start - 0.5], color='black', linestyle='-', linewidth=1)
    # 垂直分隔线
    ax.plot([end + 0.5, end + 0.5], [start - 0.5, end + 0.5], color='black', linestyle='-', linewidth=1)




# 绘制主对角线
ax.plot([-0.5, len(sorted_topics) - 0.5], [-0.5, len(sorted_topics) - 0.5],color='black', linestyle='-', linewidth=1)



# 添加领域标签（顶部）
for i, (boundary, name) in enumerate(zip(field_boundaries, field_names)):
    start, end = boundary
    middle = (start + end) / 2
    ax.text(middle, -2, name,ha='center',va='center',fontsize=14, color='black', fontweight='bold')


# 在对角线上添加主题编号
for i, topic in enumerate(sorted_topics):
    ax.text(i-1, i+0.3, str(topic), ha='center', va='center', rotation=45, fontsize=9, color='black', fontweight='bold')



# 隐藏坐标轴刻度,设置边框颜色和粗细
ax.set_xticks([])
ax.set_yticks([])
ax.spines['bottom'].set_visible(False)
ax.spines['left'].set_visible(False)

ax.spines['top'].set_color('black')
ax.spines['top'].set_linewidth(1)
ax.spines['right'].set_color('black')
ax.spines['right'].set_linewidth(1)



# 保存图像
plt.savefig('grouped_heatmap（按主题的行和排序）.jpg', bbox_inches='tight', dpi=300)
plt.show()



