import pandas as pd
import numpy as np
import re
from tqdm import tqdm

data1 = pd.read_json('../3-国家参与各主题组织名录.json')
data2 = pd.read_json('../4-2023_UIA_77149_Field.json')

file_path = "Nations_Dictionary.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Nation_lines = [i.strip() for i in file.readlines()]
    
tar_data = pd.DataFrame(0, index = range(193), columns=['number', 'avg_size'])
for i in range(193):
    i_org_string = data1.iloc[i, 0]
    i_org_index = np.array([int(x) for x in i_org_string.split()])
    tar_data.iloc[i, 0] = len(i_org_index)
    i_org_sizes = data2['Nation_Member_Number'][i_org_index]
    tar_data.iloc[i, 1] = i_org_sizes.sum()/len(i_org_sizes)
    
tar_data.to_excel('6-国家参加的组织总数和组织平均规模.xlsx', index = False)