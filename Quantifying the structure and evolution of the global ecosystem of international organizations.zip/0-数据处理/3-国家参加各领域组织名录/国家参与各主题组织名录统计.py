import pandas as pd
import numpy as np
from tqdm import tqdm
import json




data = pd.read_json('2023_UIA_77149_Field.json')

file_path = "Nations_Dictionary.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Nation_lines = [i.strip() for i in file.readlines()]


#数据矩阵、国家下标、领域下标、组织下标
def add_org(df, i, j, org_index):
    raw_data = df.iloc[i, j]
    if raw_data: # 不为空
        new_data = df.iloc[i, j] + ' ' + str(org_index)
        df.iloc[i, j] = new_data
    else: # 为空
        new_data = str(org_index)
        df.iloc[i, j] = new_data
    return df
    
nations_org_number = pd.DataFrame('', \
                  index = range(len(Nation_lines)), \
                  columns = ['All',
                             'Technology and Engineering', 
                             'Society and Policy', 
                             'Religion and Culture', 
                             'Education and Research', 
                             'Resource and Environment', 
                             'Health and Wellbeing', 
                             'Economy and Development', 
                             'Defence and Security', 
                             'Sport and Entertainment ', 
                             'Art and Design',
                             'Others'])
    
for i in tqdm(range(len(data))):
    # 1、找出涉及哪些国家
    Nation_Members_indexs = []
    Nation_Members = data.loc[i, 'Nation_Member']
    if Nation_Members:
        Nation_Members_list = Nation_Members.split(';')
        Nation_Members_indexs = [Nation_lines.index(x) for x in Nation_Members_list]
    # 2、找出涉及哪些主题
    Subjects_vector = np.array(data.iloc[i, -1])
    Subjects_indexs = list(np.where(Subjects_vector == 1)[0])
    # 3、给所有国家的所有涉及主题添加
    if Nation_Members_indexs and Subjects_indexs:
        for n in Nation_Members_indexs:
            nations_org_number = add_org(nations_org_number, n, 0, i)
            for s in Subjects_indexs:
                nations_org_number = add_org(nations_org_number, n, s+1, i)
                
nations_org_number.to_json('3-国家参与各主题组织名录.json')
        


        
    
    
    
    
    

