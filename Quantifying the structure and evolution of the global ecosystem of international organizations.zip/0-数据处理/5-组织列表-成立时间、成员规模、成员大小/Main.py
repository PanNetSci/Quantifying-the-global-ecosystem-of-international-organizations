import pandas as pd
import numpy as np
from tqdm import tqdm
from scipy.stats import rankdata

data = pd.read_excel('../最终版所有数据-25268.xlsx')
# 1、记录每年每个国家参加组织的数量
df_number = pd.DataFrame(0, index = range(193), columns=range(-100, 2025)) 
for i in tqdm(range(len(data)), desc = '1'):
    i_nation_member_index_str = data.loc[i, 'Nation_Member_Index']
    if i_nation_member_index_str: # 有国家成员
        i_nation_member_index = np.array([int(x) for x in i_nation_member_index_str.split()])
        i_found_time = data.loc[i, '成立时间']
        if not pd.isnull(i_found_time):
            start_time = int(i_found_time)
            df_number.loc[i_nation_member_index, start_time:] += 1
                
df_number.to_csv('1-每个国家在每年加入的组织数量.csv', index = False)

# 2、记录每年每个国家参加组织的数量排名
df_rank = pd.DataFrame(0, index = df_number.index, columns = df_number.columns)
m, n = df_rank.shape
for col in tqdm(range(n), desc = '2'):
    ranks_asc = rankdata(df_number.iloc[:, col])  
    ranks_desc = len(df_number.iloc[:, col]) - ranks_asc + 1
    col_rank =  list(ranks_desc)
    df_rank.iloc[:, col] = col_rank  
df_rank.to_csv('2-每个国家在每年加入的组织数量排名.csv', index = False)

# 3、合并到一起成为组织的信息
size_array = np.array(pd.read_excel('../1-国家参与的组织数量.xlsx').iloc[:, 0])

tar_data = pd.DataFrame(0, index = range(len(data)), columns = ['成立时间', '成员国大小', '组织规模'])
tar_data['成立时间'] = list(data['成立时间'])
tar_data['组织规模'] = list(data['Nation_Member_Number'])

org_mem_size = []
for i in tqdm(range(len(data)), desc = '3'):
    i_found_time = data.loc[i, '成立时间']
    if not pd.isnull(i_found_time):
        start_time = int(i_found_time)
        
        i_member_string = data.loc[i, 'Nation_Member_Index']
        i_member_index = np.array([int(x) for x in i_member_string.split()])
        dangnian_size_array = np.array(df_rank.iloc[:, start_time-1])
        i_member_size = dangnian_size_array[i_member_index]
        i_member_avg_size = i_member_size.sum()/len(i_member_size)
        org_mem_size.append(i_member_avg_size)
        
    else:
        org_mem_size.append(0)

tar_data['成员国大小'] = org_mem_size
tar_data.to_csv('3-组织成立时间、成员国大小、组织规模数据.csv', index = False)