import pandas as pd
import numpy as np
from tqdm import tqdm

def read_ele(string):
    index_string_list = string.split()
    index_int_list = [int(i) for i in index_string_list]
    return index_int_list

def get_nations_org_in_year_field(year, field):
    raw_nations_orgs = nations_org_list
    new_nations_orgs = []
    for i_nation_orgs in raw_nations_orgs:
        new_i_nation_orgs = []
        for j_org in i_nation_orgs:
            if org_is_coreect(j_org, year, field):
                new_i_nation_orgs.append(j_org)
        new_nations_orgs.append(new_i_nation_orgs.copy())
    return new_nations_orgs
        
def org_is_coreect(org, year, field):
    org_year = org_info.iloc[org, 0]
    org_field = eval(org_info.iloc[org, 1])
    
    # 1、判断年份成不成立
    condition_year = True
    if pd.isnull(org_year):
        condition_year = False
    else:
        if org_year > year:
            condition_year = False
    
    # 2、判断领域成不成立
    condition_field = False
    if field == 'All':
        condition_field = True
    else:
        if org_field[field] == 1:
            condition_field = True
    
    if condition_year and condition_field:
        return True
    else:
        return False

def jaccard_coefficient(arr1, arr2):
    # 首先判断一下是不是两个都不为空
    if len(arr1) == 0 and len(arr2) == 0:
        return 0
    else:
        intersection = np.intersect1d(arr1, arr2)  # 计算交集
        union = np.union1d(arr1, arr2)  # 计算并集
        coefficient = len(intersection) / len(union)  # 计算杰卡德系数
        return coefficient

def calculate_matrix(nations_orgs):
    n = len(nations_orgs)
    target_matrix = np.zeros((n, n))
    for i in range(n):
        target_matrix[i ,i] = 1
        for j in range(i+1, n):
            target_matrix[i ,j] = jaccard_coefficient(nations_orgs[i], nations_orgs[j])
            target_matrix[j ,i] = target_matrix[i ,j]
    return target_matrix 

if __name__ == '__main__':
    nations_org = pd.read_csv('0-国家参加组织index名录.csv')
    nations_org_list = [read_ele(x) for x in nations_org.iloc[:, 0]]
    org_info = pd.read_csv('1-组织信息名录.csv')
    fields = ['All'] + list(range(10))
    
    lst = list(range(1900, 2025))
    year_incides = [lst[i:i+10] for i in range(0,len(lst),10)]
    n = 0
    
    for year in tqdm(year_incides[n], desc = 'year'):
        for field in tqdm(fields, desc = 'field'):
            new_nations_orgs = get_nations_org_in_year_field(year, field)
            target_matrix = calculate_matrix(new_nations_orgs)
            pd.DataFrame(target_matrix).to_csv('./共现概率矩阵/%s_%s.csv'%(year, field), index = False, header = None)
        
        

