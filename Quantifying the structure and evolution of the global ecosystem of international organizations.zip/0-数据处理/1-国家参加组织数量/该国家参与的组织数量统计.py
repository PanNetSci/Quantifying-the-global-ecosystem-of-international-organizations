import pandas as pd
import numpy as np
import re
from tqdm import tqdm

mapping = {
    **{i: 'G1' for i in 'ABCDF'},
    **{i: 'G2' for i in 'EKR'},
    **{i: 'G3' for i in 'ST'},
    **{i: 'G4' for i in 'GN'},
    **{i: 'G5' for i in 'HJU'}
}

data = pd.read_excel('../最终版所有数据-25268.xlsx')
    
file_path = "Nations_Dictionary.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Nation_lines = [i.strip() for i in file.readlines()]
    
'''
用于存储每个国家参与组织的数量
一个总共数量
大类一共有15个
集群一共有5个
一个所属大洲数据
'''
nations_org_number = pd.DataFrame(0, \
                  index = range(len(Nation_lines)), \
                  columns = ['all', \
                              'A', 'B', 'C', 'D', 'F', \
                              'E', 'K', 'R', \
                              'S', 'T', \
                              'G', 'N', \
                              'H', 'J', 'U',\
                              'G1', 'G2', 'G3', 'G4', 'G5',\
                              'Continent'])

for i in tqdm(range(len(data))):
    Nation_Members = data.loc[i, 'Nation_Member']
    if Nation_Members:
        Nation_Members_list = Nation_Members.split(';')
        i_type1 = data.loc[i, 'Type1'].strip()
        for Nation in Nation_Members_list:
            index = Nation_lines.index(Nation)
            nations_org_number.loc[index, 'all'] += 1
            nations_org_number.loc[index, i_type1] += 1
            nations_org_number.loc[index, mapping[i_type1]] += 1

nations_org_number.to_excel('国家参与的组织数量.xlsx', index=False)




