import pandas as pd
import numpy as np
from tqdm import tqdm

def read_ele(string):
    index_string_list = string.split()
    index_int_list = [int(i) for i in index_string_list]
    return index_int_list

def jaccard_coefficient(arr1, arr2):
    # 首先判断一下是不是两个都不为空
    if len(arr1) == 0 and len(arr2) == 0:
        return 0
    else:
        intersection = np.intersect1d(arr1, arr2)  # 计算交集
        union = np.union1d(arr1, arr2)  # 计算并集
        coefficient = len(intersection) / len(union)  # 计算杰卡德系数
        return coefficient

def calculate_matrix(nations_orgs):
    n = len(nations_orgs)
    target_matrix = np.zeros((n, n))
    for i in range(n):
        target_matrix[i ,i] = 1
        for j in range(i+1, n):
            target_matrix[i ,j] = jaccard_coefficient(nations_orgs[i], nations_orgs[j])
            target_matrix[j ,i] = target_matrix[i ,j]
    return target_matrix 

data = pd.read_json('../3-国家参与各主题组织名录.json')
data_abb = pd.read_csv('国家的简称.csv', encoding='gbk')
data['简称'] = data_abb['简称']

for i in tqdm(range(10), desc = 'field'):
    i_data = data.copy()
    nations_org_list = [read_ele(x) for x in data.iloc[:, i+1]]
    nations_org_num = [len(x) for x in nations_org_list]
    i_data['国家参加组织数量'] = nations_org_num
    sorted_i_data = i_data.sort_values(by = '国家参加组织数量', ascending = False)
    sorted_nations_org_list = [read_ele(x) for x in sorted_i_data.iloc[:, i+1]]
    
    target_matrix = calculate_matrix(sorted_nations_org_list)
    target_matrix = pd.DataFrame(target_matrix)
    target_matrix.index = list(sorted_i_data['简称'])
    target_matrix.to_excel('./Data/领域%s共现概率矩阵.xlsx'%(i+1))
    
    # break