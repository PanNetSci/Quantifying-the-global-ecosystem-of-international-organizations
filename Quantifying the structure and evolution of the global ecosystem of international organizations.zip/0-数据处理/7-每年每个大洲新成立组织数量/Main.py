import pandas as pd
import numpy as np

data = pd.read_excel('../最终版所有数据-25268.xlsx')

file_path = "Nations_Dictionary.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Nation_lines = [i.strip() for i in file.readlines()]
    
file_path = "Country_Continent.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Continent_lines = file.readlines()
    Continent_lines = [i.strip().split()[-1] for i in Continent_lines]
    
Continents = ['Asia', 'Europe', 'Africa', 'Oceania', 'North_America', 'South_America']
target_data = pd.DataFrame(0, index = Continents, columns = range(1900, 2025))
for c in Continents:
    nations = [Nation_lines[idx] for idx in range(193) if Continent_lines[idx] == c] 
    for y in range(1900, 2025):
        mask = np.isin(data['总部国家'], nations)
        data_need_1 = data.iloc[mask, :]
        data_need_2 = data_need_1[data_need_1['成立时间'] == y]
        target_data.loc[c, y] = len(data_need_2)
    # break
target_data.to_excel('总部在各个大洲组织每年成立数量.xlsx')
