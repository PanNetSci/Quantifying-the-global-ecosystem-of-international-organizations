import pandas as pd
import numpy as np
from tqdm import tqdm
import json



data = pd.read_json('2023_UIA_77149_Field.json')

nations_org_list = pd.DataFrame('', index=range(193), columns=range(10))
nations_org_number = pd.DataFrame(0, index=range(193), columns=range(20))

file_path = "Nations_Dictionary.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Nation_lines = [i.strip() for i in file.readlines()]

number = len(data)
for i in tqdm(range(number)):
    # 1、找出涉及哪些国家
    Nation_Members_indexs = []
    Nation_Members = data.loc[i, 'Nation_Member']
    if Nation_Members:
        Nation_Members_list = Nation_Members.split(';')
        Nation_Members_indexs = [Nation_lines.index(x) for x in Nation_Members_list]
    # 2、找出涉及哪些主题
    fields = np.array(data.loc[i, "Field"])[:-1]
    fields_index = list(np.where(fields == 1)[0])

    # 3、给所有国家的所有涉及主题添加
    if Nation_Members_indexs and fields_index:
        for s in fields_index:
            for n in Nation_Members_indexs:
                nations_org_list.loc[n, s] += str(i)
                nations_org_list.loc[n, s] += ' '
                nations_org_number.loc[n, s] += 1
    # break
                
for i in tqdm(range(193)):
    for j in range(10):
        i_j_org_list = nations_org_list.iloc[i, j].split()
        i_j_org_list = [int(x) for x in i_j_org_list]
        i_j_org_size_list = [data.loc[x, 'Nation_Member_Number'] for x in i_j_org_list]
        i_j_org_avg_size = sum(i_j_org_size_list) / len(i_j_org_size_list)
        nations_org_number.iloc[i, j+10] = i_j_org_avg_size
                
nations_org_number.to_excel('2-国家参与各主题组织数量及平均规模.xlsx', index=False)
        


        
    
    
    
    
    

