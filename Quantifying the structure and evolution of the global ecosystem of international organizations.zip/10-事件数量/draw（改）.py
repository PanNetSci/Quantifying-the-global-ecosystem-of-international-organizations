import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
import seaborn as sns
import datetime



# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 42



# # 1、处理数据，并保存，以后直接读就行-------------------------------------------------------------------------------------------------------
# # 读取数据
# df = pd.read_excel('events_info.xlsx')
#
# # 筛选1900-2024年的数据
# df = df[(df['Year'] >= 1900) & (df['Year'] <= 2024)]
#
# # 创建年度列
# df['Year'] = df['Year'].astype(int)
#
# # 按年度和领域分组统计
# year_field_counts = df.groupby(['Year', 'Field']).size().unstack(fill_value=0)
#
#
#
# # 保存数据
# year_field_counts.to_csv('year_field_counts.csv')





# 2、使用时直接读取处理好的数据-------------------------------------------------------------------------------------------------------
year_field_counts = pd.read_csv('year_field_counts.csv', index_col='Year')
year_field_counts.columns = year_field_counts.columns.astype(int)  # 将列名转换为整数






# 3、画图，设置颜色方案-------------------------------------------------------------------------------------------------------
field_colors = {
    1: '#82B0D2',      # 蓝色
    2: '#E25C5C',      # 橙色
    3: '#FFB061',      # 绿色
    4: '#BECFC9',      # 红色
    5: '#C1DE9C',      # 紫色
    6: '#E7DAD2',    # 棕色
    7: '#BEB8DC',      # 粉色
    8: '#999999',      # 灰色
    9: '#F3D266',  # 黄绿色
    10: '#F6CAE5'   # 青色
}

# 把领域标签换成简称
field_labels = ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']
field_mapping = {i+1: field_labels[i] for i in range(10)}  # Maps 1-10 to your labels



# # 定义非线性变换函数
# def transform_year(year):
#     """压缩1900-1945年区间，保持1945年后线性"""
#     if year < 1945:
#         # 对1945年前的年份进行非线性压缩
#         # 使用对数变换，可以根据需要调整压缩程度
#         return 1945 - (1945 - 1900) * np.log1p(1945 - year) / np.log1p(1945 - 1900)
#     else:
#         return year


def transform_year(year):
    """压缩1900-1945年区间（区间内保持线性），保持1945年后不变"""
    compression_factor = 0.2  # 压缩因子，0.3表示压缩为原来的30%长度，可根据需要调整

    cy= 1950

    if year < cy:
        # 线性压缩1900-1945区间
        compressed_length = (cy - 1900) * compression_factor
        return 1900 + (year - 1900) * (compressed_length / (cy - 1900))
    else:
        # 1945年后保持不变
        return year + (cy - 1900) * (compression_factor - 1)  # 调整1945年后年份使其连续





# 创建转换后的x轴值
years = year_field_counts.index
transformed_years = np.array([transform_year(y) for y in years])




# 创建图形
plt.figure(figsize=(9.4, 7.1))


# 绘制每个领域的曲线
for field in year_field_counts.columns:
    # 使用平滑曲线
    sns.lineplot(x=transformed_years,
                 y=year_field_counts[field],
                 label=field_mapping[field],
                 color=field_colors[field],
                 linewidth=1.5,
                 # marker='o',
                 # markersize=6,
                 alpha=0.85)




# 添加2019年新冠疫情的标记线
transformed_2019 = transform_year(2019)
plt.axvline(x=transformed_2019, color='#a6a6a6', linestyle='--', linewidth=2,  zorder=-1)
plt.text(x=transform_year(1975.5), y=3271, s='The COVID-19 pandemic', color='#a6a6a6',  fontsize=25, rotation=0, verticalalignment='top')




# 定义主要刻度年份
major_years = list(range(1900, 2026, 10))
major_years.sort()

# 计算转换后的刻度位置
transformed_ticks = [transform_year(y) for y in major_years]




# 定义要显示的标签年份 - 只显示1900和1945后的
label_years = [1900] + [y for y in major_years if y >= 1950]



# 设置刻度
plt.xticks(transformed_ticks)
ax = plt.gca()
ax.set_xticks(transformed_ticks, minor=False)  # 主刻度
ax.set_xticklabels(['' if y not in label_years else str(y) for y in major_years], rotation=90, fontsize = 38)  # 只显示指定标签
plt.yticks(fontsize=38)


# 设置轴限制
plt.xlim(transform_year(1899), transform_year(2025))
plt.ylim(-25, year_field_counts.max().max() * 1.15)  # 设置y轴范围为0到最大值的1.2倍


# 添加标题和标签
plt.xlabel('Year', fontsize = 42)
plt.ylabel('Number of events', fontsize = 42)



# 优化图例
plt.legend(
    bbox_to_anchor=(0.045, 0.8),
    loc='upper left',
    borderaxespad=0.,
    handlelength=1.5,  # 减小线条长度
    handletextpad=0.6,  # 调整文字与线条的间距
    frameon=True,  # 不去掉图例边框
    ncol=2,  # 设置10列使所有图例项排成一行
    fontsize=25,  # 可选：调整字体大小以适应水平排列
    columnspacing=1  # 减小列之间的间隔，默认是2.0
)


# # 设置y轴为对数刻度
# plt.yscale('log')


# 保存图像
plt.savefig("field_all_number_of_events_改.jpg", dpi=330, bbox_inches='tight')

# 显示图形
# plt.show()


























