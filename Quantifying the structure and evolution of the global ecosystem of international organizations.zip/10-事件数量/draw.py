import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
import seaborn as sns



# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14



# 1、处理数据，并保存，以后直接读就行-------------------------------------------------------------------------------------------------------
# 读取数据
df = pd.read_excel('events_info.xlsx')

# 筛选1900-2024年的数据
df = df[(df['Year'] >= 1900) & (df['Year'] <= 2024)]

# 创建年度列
df['Year'] = df['Year'].astype(int)

# 按年度和领域分组统计
year_field_counts = df.groupby(['Year', 'Field']).size().unstack(fill_value=0)



# 保存数据
year_field_counts.to_csv('year_field_counts.csv')





# 2、使用时直接读取处理好的数据-------------------------------------------------------------------------------------------------------
year_field_counts = pd.read_csv('year_field_counts.csv', index_col='Year')
year_field_counts.columns = year_field_counts.columns.astype(int)  # 将列名转换为整数






# 3、画图，设置颜色方案-------------------------------------------------------------------------------------------------------
field_colors = {
    1: '#82B0D2',      # 蓝色
    2: '#E25C5C',      # 橙色
    3: '#FFB061',      # 绿色
    4: '#BECFC9',      # 红色
    5: '#C1DE9C',      # 紫色
    6: '#E7DAD2',    # 棕色
    7: '#BEB8DC',      # 粉色
    8: '#999999',      # 灰色
    9: '#F3D266',  # 黄绿色
    10: '#F6CAE5'   # 青色
}

# 把领域标签换成简称
field_labels = ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']
field_mapping = {i+1: field_labels[i] for i in range(10)}  # Maps 1-10 to your labels


# 创建图形
plt.figure(figsize=(14, 8), dpi=100)




# 添加2019年新冠疫情的标记线
plt.axvline(x=2019, color='black', linestyle='--', linewidth=1.5, alpha=0.55, zorder=-1)
plt.text(x=1994.5, y=3220, s='The COVID-19 pandemic', color='black', alpha=0.75, fontsize=14, rotation=0, verticalalignment='top')



# 绘制每个领域的曲线
for field in year_field_counts.columns:
    # 使用平滑曲线
    sns.lineplot(data=year_field_counts[field],
                 label=field_mapping[field],
                 color=field_colors[field],
                 linewidth=1.5,
                 # marker='o',
                 # markersize=6,
                 alpha=0.85)


# 添加标题和标签
plt.xlabel('Year')
plt.ylabel('Number of events')


# 优化图例
plt.legend(
    bbox_to_anchor=(0.1, 0.97),
    loc='upper left',
    borderaxespad=0.,
    handlelength=1.2,  # 减小线条长度
    handletextpad=0.6,  # 调整文字与线条的间距
    frameon=True,  # 不去掉图例边框
    ncol=5,  # 设置10列使所有图例项排成一行
    fontsize=14  # 可选：调整字体大小以适应水平排列
)



# 设置x轴刻度
plt.xticks(np.arange(1900, 2025, 10), rotation=0)
plt.xlim(1899, 2025)

# 在设置x轴刻度后添加y轴范围调整
plt.ylim(-25, year_field_counts.max().max() * 1.1)  # 设置y轴范围为0到最大值的1.2倍



# # 设置y轴为对数刻度
# plt.yscale('log')


# 保存图像
plt.savefig("field_all_number_of_events.jpg", dpi=300, bbox_inches='tight')


# 显示图形
plt.show()







# 4、创建局部放大图（1970-1990）-------------------------------------------------------------------------------------------------------
plt.figure(figsize=(5, 3.5), dpi=100)  # 稍小的图形尺寸适合局部展示

# 设置时间段范围
start_year, end_year = 1980, 1995

# 绘制每个领域的曲线（相同样式）
for field in year_field_counts.columns:
    sns.lineplot(data=year_field_counts[field].loc[start_year:end_year],
                 label=field_mapping[field],
                 color=field_colors[field],
                 legend=False,
                 linewidth=1.5,  # 局部放大可以加粗线条
                 alpha=0.9)

# 设置刻度
plt.xticks(np.arange(start_year, end_year+2, 5))  # 每5年一个刻度
plt.xlim(start_year-0.2, end_year+0.2)


# 自动调整y轴范围（只考虑这段时间的数据）
period_data = year_field_counts.loc[start_year:end_year]
plt.ylim(-50, period_data.max().max() * 1.05)

# 清空标签
plt.xlabel('')
plt.ylabel('')

# 保存图像
plt.savefig(f"events_{start_year}_{end_year}_zoom.jpg",dpi=300,bbox_inches='tight')

plt.show()








# 5、创建局部放大图（2018-2021）-------------------------------------------------------------------------------------------------------
plt.figure(figsize=(5, 3.5), dpi=100)  # 稍小的图形尺寸适合局部展示

# 设置时间段范围
start_year, end_year = 2018, 2021

# 绘制每个领域的曲线（相同样式）
for field in year_field_counts.columns:
    sns.lineplot(data=year_field_counts[field].loc[start_year:end_year],
                 label=field_mapping[field],
                 color=field_colors[field],
                 legend=False,
                 linewidth=1.5,  # 局部放大可以加粗线条
                 alpha=0.9)

# 设置刻度
plt.xticks(np.arange(start_year, end_year+1, 1))  # 每5年一个刻度
plt.xlim(start_year-0.04, end_year+0.04)


# 自动调整y轴范围（只考虑这段时间的数据）
period_data = year_field_counts.loc[start_year:end_year]
plt.ylim(-50, period_data.max().max() * 1.05)

# 清空标签
plt.xlabel('')
plt.ylabel('')

# 保存图像
plt.savefig(f"events_{start_year}_{end_year}_zoom.jpg",dpi=300,bbox_inches='tight')

plt.show()
