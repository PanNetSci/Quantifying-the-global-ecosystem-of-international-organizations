import numpy as np
import matplotlib.pyplot as plt
from matplotlib.dates import YearLocator, DateFormatter
import datetime
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
import seaborn as sns

# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14


import numpy as np
import matplotlib.pyplot as plt
from matplotlib.dates import YearLocator, DateFormatter
import datetime
from matplotlib.ticker import FuncFormatter

# 创建数据
years = np.arange(1900, 2025)
values = np.random.normal(loc=50, scale=10, size=len(years)).cumsum()
dates = [datetime.datetime(year, 1, 1) for year in years]

# 将日期转换为数值（用于非线性变换）
date_nums = np.array([date.toordinal() for date in dates])

# 定义非线性变换函数（压缩1900-1950年区间）
def transform(x):
    ref = datetime.datetime(1950, 1, 1).toordinal()
    if x < ref:
        # 对1950年前的日期进行压缩
        return ref - (ref - x)**0.5 * 100
    else:
        return x

transformed_dates = np.array([transform(d) for d in date_nums])

# 创建图形
plt.figure(figsize=(12, 6))

# 绘制图形
plt.plot(transformed_dates, values, color='blue')

# 设置x轴格式
ax = plt.gca()

# 自定义刻度标签
def format_func(x, pos):
    date = datetime.datetime.fromordinal(int(x))
    return date.strftime('%Y')

ax.xaxis.set_major_formatter(FuncFormatter(format_func))

# 设置主要刻度
major_years = range(1900, 2025, 10)
major_dates = [datetime.datetime(year, 1, 1).toordinal() for year in major_years]
transformed_major = [transform(d) for d in major_dates]
ax.set_xticks(transformed_major)
ax.set_xticklabels([str(year) for year in major_years])

plt.xticks(rotation=45)
plt.grid(True, linestyle='--', alpha=0.6)
plt.title('时间序列图 (1900-2024) - 非线性时间轴', fontsize=14)
plt.xlabel('年份 (1900-1950年区间被压缩)', fontsize=12)
plt.ylabel('数值', fontsize=12)

plt.tight_layout()
plt.show()