import re
import pandas as pd


dalingyu_id = [3, 2, 6, 3, 10, 6, 3, 2, 4, 8, 2, 2, 7, 2, 5, 7, 6, 2, 7, 2, 1, 0, 6, 4, 10, 8, 3, 2, 7, 8, 7, 2, 4, 10, 4, 6, 7, 1, 5, 2, 4, 3, 4, 4, 7, 3, 2, 5, 8, 2, 2, 1, 1, 1, 6, 7, 1, 5, 4, 6, 4, 9, 8, 3, 0, 5, 2, 1, 2, 2, 4, 7, 1, 9, 7, 7, 2, 6, 6, 5, 5, 5, 5, 5, 6, 6, 5, 1, 4, 5, 5, 5, 5, 5, 5, 5, 5]

# 输出data
df_list = []

all_data = pd.read_excel("data_25268.xlsx")
for idx, data in all_data.iterrows():
    event_data = data["All_Events"]

    if idx % 1000 == 0:
        print(str(idx)+"/25268")

    if isinstance(event_data, float) or isinstance(data["主题序号"], float):
        continue

    # 分割数据
    event_data = event_data.replace(';', '\n')

    # 正则表达式模式
    pattern = r'(\d{4}(?:-\d{2}-\d{2})?)\s*\|\s*([^,]*?(?:,\s*[^–]+)?)?\s*–\s*(.+)'

    # 提取数据
    matches = re.findall(pattern, event_data)

    # 创建DataFrame
    df = pd.DataFrame(matches, columns=['Year', 'Location', 'Event'])

    # 分离城市和国家
    df['City'] = df['Location'].apply(lambda x: x.split(',')[0].strip() if ',' in x else '')
    df['Country'] = df['Location'].apply(lambda x: x.split(',')[-1].strip() if ',' in x else x.strip())

    # 清理数据
    df['Year'] = df['Year'].str.extract(r'(\d{4})')  # 提取年份

    lingyu_id = data["主题序号"].split(' ')
    flag = [0] * 10
    for i in range(97):
        if lingyu_id[i] == '1':
            if dalingyu_id[i] > 0 and flag[dalingyu_id[i]-1] == 0:
                df['Field'] = dalingyu_id[i]
                df = df[['Year', 'City', 'Country', 'Event', 'Field']]  # 重新排列列
                df_list.append(df)
                flag[dalingyu_id[i]-1] = 1


all_df = pd.concat(df_list, ignore_index=True)

# 保存到CSV文件
all_df.to_excel('events_info.xlsx', index=False)
