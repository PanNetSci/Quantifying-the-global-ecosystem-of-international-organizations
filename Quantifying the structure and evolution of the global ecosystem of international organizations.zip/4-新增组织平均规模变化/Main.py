import pandas as pd
import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib as mpl 


import matplotlib
matplotlib.use('TkAgg')
mpl.rcParams['font.family'] = 'Times New Roman'  # 注意：这可能在某些系统上不起作用  
mpl.rcParams['font.size'] = 42

data = pd.read_excel('最终版所有数据-25268.xlsx')

year = range(1900, 2024)
target_data = pd.DataFrame(columns = year)
for y in tqdm(year, desc = 'Calculating'):
    filtered_df = data[data['成立时间'] == y]
    size_list = filtered_df['Nation_Member_Number']
    average_size = sum(size_list)/len(size_list)
    STD = np.std(size_list)
    
    target_data.loc['average_size', y] = average_size
    rate1 = 0.1

    target_data.loc['max_size1', y] = average_size + rate1 * STD
    target_data.loc['min_size1', y] = average_size - rate1 * STD
    
    rate2 = 0.3
    target_data.loc['max_size2', y] = average_size + rate2 * STD
    target_data.loc['min_size2', y] = average_size - rate2 * STD
  
# base_size = 0.9
fig, ax = plt.subplots(figsize = (8.8, 7.3), constrained_layout = True)

n = 1

ax.plot(year[::n], target_data.loc['average_size', :][::n], lw = 1.5, label = 'Annual average scale', color = '#F8B072')
# 
# ax.plot(year[::n], target_data.loc['average_size', :][::n], lw = 2, label = 'Annual average scale', color = '#F8B072')
ax.fill_between(year[::n], list(target_data.loc['min_size1', :])[::n], list(target_data.loc['max_size1', :])[::n], facecolor='#F8B072', alpha=0.35, label = 'Variance rate = 0.1') 
ax.fill_between(year[::n], list(target_data.loc['min_size2', :])[::n], list(target_data.loc['max_size2', :])[::n], facecolor='#F8B072', alpha=0.15, label = 'Variance rate = 0.3')

average_size_all = sum(target_data.loc['average_size', :])/len(target_data.loc['average_size', :])
plt.axhline(y = average_size_all, linestyle='--', label = 'Overall average scale', lw = 2, color = '#a6a6a6', zorder=-1)
plt.text(2023, 32, '%.2f'%average_size_all, va='center', ha='right', color = '#a6a6a6', fontsize = 25)



# 设置坐标轴范围和刻度
ax = plt.gca()

# 设置X轴范围和刻度
ax.set_xlim(1899, 2024)  # 设置X轴范围
ax.set_xticks(range(1900, 2025, 15))  # 每20年一个刻度
ax.set_xticklabels(range(1900, 2025, 15), rotation=90, fontsize=38)  # 设置刻度标签

# 设置Y轴范围和刻度
ax.set_ylim(-1, 90)  # 设置Y轴范围
ax.set_yticks(range(0, 90, 25))  # 每20一个刻度
ax.set_yticklabels(range(0, 90, 25), fontsize=38)  # 设置刻度标签







# 设置轴标签
plt.xlabel('Year', fontsize = 42)
plt.ylabel('Scale', fontsize = 42)


plt.legend(loc = 'upper right', fontsize = 25, handlelength=1.6, handletextpad=0.6)
plt.savefig('Main_改.jpg', dpi = 300, bbox_inches = 'tight')