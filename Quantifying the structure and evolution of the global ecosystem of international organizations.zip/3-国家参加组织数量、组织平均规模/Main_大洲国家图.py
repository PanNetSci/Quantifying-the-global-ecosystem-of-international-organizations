import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
from tqdm import tqdm
import matplotlib as mpl 
import matplotlib.ticker as ticker  

def millions(x, pos):  
    # 这里的x是Y轴上的原始刻度值  
    # pos是刻度的位置（通常不需要）  
    if x == 0:
        return ''
    else:
        return f'{x / 1000}k'  # 除以100并格式化为整数，后面加'%'  

mpl.rcParams['font.family'] = 'Times New Roman'  # 注意：这可能在某些系统上不起作用  
mpl.rcParams['font.size'] = 45

file_path = "Nations_Dictionary.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Nations_lines = file.readlines()
    Nations_lines_raw = [i.strip() for i in Nations_lines]

file_path = "Country_Continent.txt"
with open(file_path, "r", encoding="utf-8") as file:
    Continent_lines = file.readlines()
    Continent_lines = [i.strip().split()[-1] for i in Continent_lines]
    
data1 = pd.read_json('../0-【数据处理】/3-国家参与各主题组织名录.json')
data2 = pd.read_json('../0-【数据处理】/2023_UIA_77149_Field.json')
data3 = pd.read_csv('国家的简称.csv', encoding='gbk')


nations_org_list = []
for i in data1['All']:
    i_org_list = np.array([int(x) for x in i.split()])
    nations_org_list.append(i_org_list)

nations_org_size_list = [list(data2['Nation_Member_Number'][x]) for x in nations_org_list]

# 数据汇总
data_all = pd.DataFrame(0, index = Nations_lines_raw, columns = ['参加组织数量','平均规模','方差'])
data_all['参加组织数量'] = [len(x) for x in nations_org_list]
data_all['平均规模'] = [sum(x)/len(x) for x in nations_org_size_list]
data_all['方差'] = [np.var(x) for x in nations_org_size_list]
data_all['大洲'] = Continent_lines
data_all['简称'] = list(data3['简称'])
df_sorted = data_all.sort_values(by='参加组织数量', ascending=True)  

# 绘图分6个子图
n = 10
fig, axs = plt.subplots(nrows = 2, ncols = 3, figsize = (4*n, 2*n)) 
plt.subplots_adjust(wspace = 0.5, hspace = 0.4)
m_list = [3,3,4,1,2,1]
# m_list = [1,1,1,1,1,1]

Continents = ['Asia', 'Europe', 'Africa', 'Oceania', 'North_America', 'South_America']
Continents_name = ['Asia', 'Europe', 'Africa', 'Oceania', 'North America', 'South America']
# Continents = ['Asia', 'Europe', 'Africa']
# Continents = ['Asia']

for i, ax1 in tqdm(enumerate(axs.flat)):
    # 先找出有哪些
    c = Continents[i]
    need_index = np.where(df_sorted['大洲'] == c)[0]
    need_data = df_sorted.iloc[need_index, :]
    
    # 绘图
    x = range(len(need_data.index))

    # ax1用于绘制柱状图
    ax1.bar(x, need_data['参加组织数量'], align='center', color = '#CFA8D0', alpha = 0.5) 
    ax1.set_ylim(0, 2*max(need_data['参加组织数量']))
    m = m_list[i]
    ax1.set_xticks(x[::m])  # 设置这些位置为刻度  
    ax1.set_xticklabels(need_data['简称'][::m], rotation=90, fontsize = 35)  # 设置刻度标签并旋转45度
    ax1.set_ylabel("Number", labelpad = 10)
    ax1.set_title(Continents_name[i])
    
    # 使用FuncFormatter来应用自定义的格式化函数  
    ax1.yaxis.set_major_formatter(ticker.FuncFormatter(millions))  

    # ax2用于绘制误差棒
    ax2 = ax1.twinx() 
    ax2.errorbar(x, need_data['平均规模'], yerr = need_data['方差']/130, fmt='.-', ecolor='#B7DBBE', color='#FFD477',\
             elinewidth = 3, linewidth = 3,\
             markersize = 18)
    ax2.set_ylim(-150, 160)
    ax2.set_yticks([0,100])
    ax2.set_ylabel("Average scale", rotation = -90, labelpad = 40)
    
    # break
    
# 手工制作一个图例
# 创建一个矩形（柱子）作为图例元素  
legend_rect = mpatches.Patch(color = '#CFA8D0', label = "Number")

# 创建两条线作为图例元素  
legend_line1 = mlines.Line2D([], [], color='#FFD477', marker='.', linestyle='-', label = "Average scale") 
legend_line2 = mlines.Line2D([], [], color='#B7DBBE', linestyle='-', label = "Variance")  

patches = [legend_rect, legend_line1, legend_line2]

fig.legend(handles = patches, ncol=3, loc='upper center', bbox_to_anchor=(0.5, 1), fontsize = 45, columnspacing = 5,)

plt.savefig('6个大洲图.jpg', dpi = 500, bbox_inches = 'tight')
    
    
    
    
    
    
    
    
    