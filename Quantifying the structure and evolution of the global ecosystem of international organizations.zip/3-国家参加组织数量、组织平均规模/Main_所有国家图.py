import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
import matplotlib as mpl 

mpl.rcParams['font.family'] = 'Times New Roman'  # 注意：这可能在某些系统上不起作用  
mpl.rcParams['font.size'] = 42

file_path = "Nations_Dictionary.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Nations_lines = file.readlines()
    Nations_lines_raw = [i.strip() for i in Nations_lines]
    
data1 = pd.read_json('../0-【数据处理】/3-国家参与各主题组织名录.json')
data2 = pd.read_json('../0-【数据处理】/2023_UIA_77149_Field.json')
data3 = pd.read_csv('国家的简称.csv', encoding='gbk')

nations_org_list = []
for i in data1['All']:
    i_org_list = np.array([int(x) for x in i.split()])
    nations_org_list.append(i_org_list)

nations_org_size_list = [list(data2['Nation_Member_Number'][x]) for x in nations_org_list]

# 数据汇总
data_all = pd.DataFrame(0, index = Nations_lines_raw, columns = ['参加组织数量','平均规模','方差'])
data_all['参加组织数量'] = [len(x) for x in nations_org_list]
data_all['平均规模'] = [sum(x)/len(x) for x in nations_org_size_list]
data_all['方差'] = [np.var(x) for x in nations_org_size_list]
data_all['简称'] = list(data3['简称'])
df_sorted = data_all.sort_values(by='参加组织数量', ascending=True)  

# 绘图
fig, ax1 = plt.subplots(figsize = (15.1, 8), constrained_layout = True) 
x = range(len(df_sorted.index))

# ax1用于绘制柱状图
ax1.bar(x, df_sorted['参加组织数量'], align='center', color = '#CFA8D0', alpha = 0.5) 
ax1.set_ylim(0, 2.2*max(df_sorted['参加组织数量']))
ax1.set_yticks([0, 5000, 10000, 15000, 20000, 25000])
ax1.set_yticklabels(['0','5k','10k','15k','20k','25k'], fontsize = 42)
ax1.set_xlim(-5, 197) 

n = 12
ax1.set_xticks(x[::n])  # 设置这些位置为刻度  
ax1.set_xticklabels(df_sorted['简称'][::n], rotation=90, fontsize = 35)  # 设置刻度标签并旋转45度
ax1.set_ylabel("Number", fontsize = 45)

# ax2用于绘制误差棒
ax2 = ax1.twinx() 
ax2.errorbar(x, df_sorted['平均规模'], yerr = df_sorted['方差']/130, fmt='.-', \
             ecolor='#B7DBBE', color='#FFD477',\
             elinewidth = 1, linewidth = 1,\
             markersize = 5)
    # e表示误差线
ax2.set_ylim(-100, 150)
ax2.set_yticks([0,100], [0, 100], fontsize = 42)
ax2.set_ylabel("Average scale", fontsize = 45)


# 手工制作一个图例
# 创建一个矩形（柱子）作为图例元素  
legend_rect = mpatches.Patch(color = '#CFA8D0', label = "Number")
    
# 创建两条线作为图例元素  
legend_line1 = mlines.Line2D([], [], color='#FFD477', marker='.', linestyle='-', label = "Average scale") 
legend_line2 = mlines.Line2D([], [], color='#B7DBBE', linestyle='-', label = "Variance")  

patches = [legend_rect, legend_line1, legend_line2]
plt.legend(handles=patches, fontsize = 35, loc = 'lower left', bbox_to_anchor = (0, 0.10))

# plt.savefig('所有国家_tight.jpg', dpi = 900, bbox_inches = 'tight')
plt.savefig('所有国家.jpg', dpi = 900)