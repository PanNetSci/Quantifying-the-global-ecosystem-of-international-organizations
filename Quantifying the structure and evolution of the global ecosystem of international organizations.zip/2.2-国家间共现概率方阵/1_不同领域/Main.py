import pandas as pd
import numpy as np
import seaborn as sns
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.colors as mcolors
from tqdm import tqdm

mpl.rcParams['font.family'] = 'Times New Roman' 
mpl.rcParams['font.size'] = 27
my_colorbar = mcolors.LinearSegmentedColormap.from_list('',['#9CBEE0', '#F9F9F9', '#C9A1CA'])
my_norm = mcolors.LogNorm(vmin = 0.015, vmax = 1, clip = True)

# 用一个子图形式绘制
field_labels =  ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']

# 在各个子图上绘制散点图
for i, label in tqdm(enumerate(field_labels), desc = 'plots'):  
    n = 1.5
    fig, ax = plt.subplots(figsize=(8 * n, 6.6 * n))  # 设置图形的大小

    data = pd.read_excel('./Data/领域%s共现概率矩阵.xlsx'%(i+1), index_col = 0)
    sns.heatmap(data, annot = False, cmap = my_colorbar, norm = my_norm, cbar = True)
    # ax.set_title(field_labels[i])
    
    tick_labels = list(data.index)
    ticks = list(range(193))
    inter = 15
    ax.set_xticks(ticks[::inter], tick_labels[::inter])
    ax.set_yticks(ticks[::inter], tick_labels[::inter])
    
    plt.savefig('./figs/%s.jpg'%label, dpi = 400, bbox_inches = 'tight')
    plt.close()
    
    # break


