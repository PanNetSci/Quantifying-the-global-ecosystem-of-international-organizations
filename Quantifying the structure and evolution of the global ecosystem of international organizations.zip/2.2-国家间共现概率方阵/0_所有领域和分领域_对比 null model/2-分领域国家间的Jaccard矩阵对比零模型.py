import pandas as pd
import numpy as np
import os
from Loader import loader
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl
from matplotlib.colors import LogNorm, LinearSegmentedColormap



# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14







# 国家重新选择组织，随机种子可以设定以保证结果的可复现
def generate_new_matrix(matrix, seed=None):
    num_countries, num_organizations = matrix.shape
    country_counts = np.sum(matrix, axis=1)  # 统计每个国家加入组织的总数

    # 设置随机数生成器的种子
    if seed is not None:
        np.random.seed(seed)

    # 创建新矩阵
    new_matrix0 = np.zeros((num_countries, num_organizations), dtype=int)

    # 随机分配组织
    for i in range(num_countries):
        # 随机选择 country_counts[i] 个组织
        selected_organizations = np.random.choice(num_organizations, size=country_counts[i], replace=False)
        new_matrix0[i, selected_organizations] = 1

    return new_matrix0


# 计算 Jaccard 的函数
def jaccard_similarity(matrix, i, j):   # matrix为国家组织的关联矩阵, i为第一个国家, j为第二个国家，返回这两个国家的Jaccard值
    # 获取两个国家的行向量
    row_i = matrix[i, :]
    row_j = matrix[j, :]

    # 计算交集大小
    intersection = np.sum(np.logical_and(row_i, row_j))

    # 计算并集大小
    union = np.sum(np.logical_or(row_i, row_j))

    # 计算Jaccard系数
    if union == 0:
        return 0  # 避免除以0
    else:
        return intersection / union



# 1至97个主题到领域的划分,有个别主题没有划分到这10个领域中 【有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0】
field1 = [21, 38, 52, 53, 54, 57, 68, 73, 88]
field2 = [2, 8, 11, 12, 14, 18, 20, 28, 32, 40, 47, 50, 51, 67, 69, 70, 77]
field3 = [1, 4, 7, 27, 42, 46, 64]
field4 = [9, 24, 33, 35, 41, 43, 44, 59, 61, 71, 89]
field5 = [15, 39, 48, 58, 66, 80, 81, 82, 83, 84, 87, 90, 91, 92, 93, 94, 95, 96, 97]
field6 = [3, 6, 17, 23, 36, 55, 60, 78, 79, 85, 86]
field7 = [13, 16, 19, 29, 31, 37, 45, 56, 72, 75, 76]
field8 = [10, 26, 30, 49, 63]
field9 = [62, 74]
field10 = [5, 25, 34]





# 1、加载数据，并且添加领域的分类------------------------------------------------------------------------------------------------------------
data = pd.read_json('org.json', encoding="utf-8")
subject = data['主题序号']
edgeNum = data.shape[0] #组织的数量
field = []


for i in range(edgeNum):
    if subject[i] != None:  #第146个组织Bonsucro没有主题
        numbers = subject[i].split() #以空格分隔
        numbers_list = [int(num) for num in numbers] #转为整型列表
        subject_index = [index+1 for index, value in enumerate(numbers_list) if value != 0]  #该组织所属主题的序号1至97
        field_index = [] #由主题序号进一步判断该组织所属领域
        if bool(set(subject_index) & set(field1)): #两个集合有交集True
            field_index.extend([1])
        if bool(set(subject_index) & set(field2)):
            field_index.extend([2])
        if bool(set(subject_index) & set(field3)):
            field_index.extend([3])
        if bool(set(subject_index) & set(field4)):
            field_index.extend([4])
        if bool(set(subject_index) & set(field5)):
            field_index.extend([5])
        if bool(set(subject_index) & set(field6)):
            field_index.extend([6])
        if bool(set(subject_index) & set(field7)):
            field_index.extend([7])
        if bool(set(subject_index) & set(field8)):
            field_index.extend([8])
        if bool(set(subject_index) & set(field9)):
            field_index.extend([9])
        if bool(set(subject_index) & set(field10)):
            field_index.extend([10])
        # 因为有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0，后续不进行统计了
        if field_index != []:
            field.append(field_index)
        else:
            field.append([0])
    else:
        field.append([0])

data['field'] = field  # 添加领域信息








# 2、 按领域分组--------------------------------------------------------------------------------------------------------------------------------

for field_id in range(1, 11):
    # 2.1 按领域分组，获取某个领域内的组织和国家
    field_orgs = data[data['field'].apply(lambda x: field_id in x)]  # 获取属于当前领域的组织

    # Nation_Member_Index 是一个 Series，每个元素是一个字符串，包含国家索引下标
    all_country_indices = set()  # 使用集合去重
    for indices_str in field_orgs['Nation_Member_Index']:
        indices = list(map(int, indices_str.split()))  # 将字符串解析为整数列表
        all_country_indices.update(indices)  # 将每个组织的国家索引下标添加到集合中

    # 将 set 转换为有序列表
    all_country_indices = sorted(all_country_indices)



    # 2.2 构建国家和组织之间的关联矩阵  matrix
    orgs = field_orgs.index  # 使用行索引作为组织标识符
    association_matrix = pd.DataFrame(0, index=all_country_indices, columns=orgs)  # 初始化全 0 矩阵

    for idx, row in field_orgs.iterrows():
        org_id = idx  # 使用行索引作为组织标识符
        indices_str = row['Nation_Member_Index']  # 获取该组织的国家索引下标字符串
        country_indices = list(map(int, indices_str.split()))  # 将字符串解析为整数列表
        for country_idx in country_indices:
            association_matrix.loc[country_idx, org_id] = 1  # 如果国家包含组织，则置为 1



    # 2.3 将 association_matrix 转换为 NumPy 矩阵，并计算所有国家对之间的 Jaccard 相似系数
    matrix = association_matrix.to_numpy()
    num_countries = matrix.shape[0]
    jaccard_matrix = np.zeros((num_countries, num_countries))

    for i in range(num_countries):
        for j in range(num_countries):
            jaccard_matrix[i, j] = jaccard_similarity(matrix, i, j)




    # 2.3.!!!!  计算国家的排名，来对比哪个国家更愿意更别人玩。还可以进一步分领域对比排名，看看有没有差异。
    # 计算每一行的Jaccard值之和
    row_sums = np.sum(jaccard_matrix, axis=1)  # 对每一行求和

    # 将国家下标索引和求和值组合成一个 DataFrame
    result_df = pd.DataFrame({
        'Country Index': np.arange(jaccard_matrix.shape[0]),  # 国家下标索引
        'Jaccard Sum': row_sums  # 每一行的 Jaccard 值之和
    })

    # 读取 Nations_Dictionary.txt 文件中的国家名称，并将国家名称添加到 result_df 中
    with open('Nations_Dictionary.txt', 'r', encoding='utf-8') as f:
        nations = [line.strip() for line in f]  # 读取每一行并去除换行符
    result_df['Country Name'] = nations

    # 按Jaccard值之和降序排列
    result_df = result_df.sort_values(by='Jaccard Sum', ascending=False)

    # 输出到Excel文件
    result_df.to_excel(f"jaccard_row_sums_{field_id}.xlsx", index=False)  # 保存为 Excel 文件，不包含行索引







    # 2.4 生成新的国家随机选组织的矩阵new_matrix，并计算新的new_jaccard_matrix
    new_matrix = generate_new_matrix(matrix, seed=42)

    num_countries = new_matrix.shape[0]
    new_jaccard_matrix = np.zeros((num_countries, num_countries))
    for i in range(num_countries):
        for j in range(num_countries):
            new_jaccard_matrix[i, j] = jaccard_similarity(new_matrix, i, j)

    # 计算对应位置的比值
    ratio_jaccard_matrix = np.divide(jaccard_matrix, new_jaccard_matrix, out=np.zeros_like(jaccard_matrix, dtype=float), where=new_jaccard_matrix != 0)

    # 绘制热力图
    plt.figure(figsize=(10, 8))
    sns.heatmap(ratio_jaccard_matrix, cmap='Purples', annot=False, cbar=True, mask=np.isnan(ratio_jaccard_matrix), norm=LogNorm())  # 如果你的数据范围是 [0, 2]，并且你希望颜色在 1 处对称（例如，1 表示中性值，小于 1 和大于 1 分别表示不同的趋势），可以设置 center=1。
    plt.title(f"Ratio of Original Jaccard Matrix to New Jaccard Matrix (Field {field_id})")
    plt.xlabel("Countries (Columns)")
    plt.ylabel("Countries (Rows)")

    # 保存为 JPG 文件，文件名为领域序号
    plt.savefig(f"field_{field_id}_heatmap.jpg", dpi=300, bbox_inches='tight')












