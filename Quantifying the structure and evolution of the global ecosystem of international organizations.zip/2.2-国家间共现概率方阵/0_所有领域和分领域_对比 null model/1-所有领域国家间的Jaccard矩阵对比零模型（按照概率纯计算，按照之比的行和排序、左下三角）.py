import pandas as pd
import numpy as np
import os
from Loader import loader
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl
from matplotlib.colors import LogNorm, LinearSegmentedColormap
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14







# 1、加载数据，转为国家与组织的关联矩阵------------------------------------------------------------------------------------------------------------
path = 'node_edge_matrix.txt'

hyperGraph = loader(path) # Hyper_graph为dataloader类的一个实例，这里调用这个类中的方法
hyperGraph.load()

matrix = hyperGraph.hyper_matrix.values # 193个节点和所有超边的关联矩阵
nodeNum, edgeNum = matrix.shape # 节点数量、超边数量




# 2、组织的总数为N，国家i和j实际参与组织的数量为Ni和Nj，则实际中两个国家共同出现在一个组织中的概率为Nij/N。-----------------------------------------------------------
    #而对于零模型，国家i出现在组织中的概率为Ni/N，国家j出现在组织中的概率为Nj/N，则零模型中两个国家共同出现在一个组织中的概率为（Ni/N）*（Nj/N）。
    #最后，计算实际与零模型的比值，为(Nij*N)/(Ni*Nj)

# 可以通过矩阵乘法一次性计算所有国家两两之间的共同组织数量,即矩阵乘以其转置,结果矩阵的第 i 行第 j 列的值就是第 i 个国家和第 j 个国家的共同组织数量。
common_orgs = np.dot(matrix, matrix.T)

# 对每一行求和，即可获得每个国家加入的国际组织数量
org_counts = np.sum(matrix, axis=1)

ratio_jaccard_matrix = np.zeros((nodeNum, nodeNum)) #存放比值的矩阵
for i in range(nodeNum):
    for j in range(nodeNum):
        if i == j:
            ratio_jaccard_matrix[i, j] = 1
        else:
            ratio_jaccard_matrix[i,j] = (common_orgs[i,j] * edgeNum) / (org_counts[i] * org_counts[j])




# 3、按照ratio_jaccard_matrix每行之和从高到低排序
# 计算ratio_jaccard_matrix每行之和（忽略nan值）
ratio_row_sums = np.nansum(ratio_jaccard_matrix, axis=1)


# 将国家下标索引与求和值组合成一个 DataFrame
result_df1 = pd.DataFrame({
    'Country Index': np.arange(193),  # 国家下标索引
    'Jaccard Ratio Sum': ratio_row_sums # 每一行的 Jaccard 值之和
})

# 读取 Nations_Dictionary.txt 文件中的国家名称，并将国家名称添加到 result_df 中
with open('Nations_Dictionary.txt', 'r', encoding='utf-8') as f:
    nations = [line.strip() for line in f]  # 读取每一行并去除换行符
result_df1['Country Name'] = nations


# 按Jaccard Ratio值之和降序排列
result_df1 = result_df1.sort_values(by='Jaccard Ratio Sum', ascending=False)


# 输出到Excel文件
result_df1.to_excel(f"jaccard_ratio_row_sums_all_(按概率纯计算).xlsx", index=False)  # 保存为 Excel 文件，不包含行索引


# 创建排序索引（从高到低）
ratio_sorted_indices = result_df1['Country Index'].values


# 对ratio_jaccard_matrix的行和列按照新的排序顺序重新排列
sorted_ratio_matrix1 = ratio_jaccard_matrix[ratio_sorted_indices][:, ratio_sorted_indices]

# 对国家名称也按新顺序排列
sorted_country_names = result_df1['Country Name'].values

# # 创建掩码矩阵，只显示左下三角（包括对角线）
mask1 = np.triu(np.ones_like(sorted_ratio_matrix1, dtype=bool), k=1)  # k=1表示从对角线以上开始掩码



#紫色渐变（与原始一致）
purple_cmap = LinearSegmentedColormap.from_list('custom_purple',
    ['#f7fcfd', '#e0ecf4', '#bfd3e6', '#9ebcda', '#8c96c6', '#a88cc6', '#9e7dbb', '#8a5a9b'])


# 1. 准备数据
# 下三角掩码（左下三角为False，右上三角为True）
lower_triangle_mask = np.triu(np.ones_like(sorted_ratio_matrix1, dtype=bool), k=1)

# 需要显示绿色的区域（下三角且值<1）
green_area = (~lower_triangle_mask) & (sorted_ratio_matrix1 <= 1)

# 需要显示紫色的区域（下三角且值≥1）
purple_area = (~lower_triangle_mask) & (sorted_ratio_matrix1 > 1)

# 2. 创建画布
plt.figure(figsize=(12, 10))

# 3. 绘制橘色背景层（只显示在下三角<=1的区域）
sns.heatmap(np.ones_like(sorted_ratio_matrix1),
            cmap=ListedColormap(['#F5B2A9']),
            annot=False,
            cbar=False,
            mask=~green_area,  # 只显示绿色区域
            square=True)


# 4. 绘制紫色热力图层（只显示下三角≥1的值）
# 对数化显示
heatmap = sns.heatmap(sorted_ratio_matrix1,
                      cmap=purple_cmap,
                      annot=False,
                      cbar=True,
                      cbar_kws={"shrink": 0.95, "aspect": 30},  # 使colorbar更细
                      mask=~purple_area,  # 只显示紫色区域
                      norm=LogNorm(vmin=1, vmax=np.nanmax(sorted_ratio_matrix1)),
                      square=True)

# 非对数化显示
# heatmap = sns.heatmap(sorted_ratio_matrix1,
#                       cmap=purple_cmap,
#                       annot=False,
#                       cbar=True,
#                       cbar_kws={"shrink": 0.95, "aspect": 30},  # 使colorbar更细
#                       mask=~purple_area,  # 只显示紫色区域
#                       vmin=1,
#                       vmax=np.nanmax(sorted_ratio_matrix1),
#                       square=True)



# 5. 添加图例
legend_elements = [
    Patch(facecolor='#F5B2A9', edgecolor='k', label='Ratio ≤ 1'),
    Patch(facecolor='#9ebcda', edgecolor='k', label='1 < Ratio ≤ 10'),
    Patch(facecolor='#a88cc6', edgecolor='k', label='Ratio > 10')
]

# 创建图例并调整大小
legend = plt.legend(
    handles=legend_elements,
    bbox_to_anchor=(0.8, 0.995),
    loc='upper left',
    handlelength=0.8,  # 控制色块长度（默认1.0）
    handleheight=0.8,  # 控制色块高度（默认1.0）
    borderaxespad=0.3  # 控制图例与边界的距离
)


# 6. 设置坐标轴标签
tick_count = 5
plt.xticks(np.arange(0, nodeNum, tick_count), sorted_country_names[::tick_count], rotation=90)
plt.yticks(np.arange(0, nodeNum, tick_count), sorted_country_names[::tick_count], rotation=0)
plt.xlabel("Countries")
plt.ylabel("Countries")



# 7. 保存图像
plt.savefig("field_all_heatmap_with_green_lower_triangle(按照概率纯计算).jpg",dpi=300,bbox_inches='tight')

plt.show()


