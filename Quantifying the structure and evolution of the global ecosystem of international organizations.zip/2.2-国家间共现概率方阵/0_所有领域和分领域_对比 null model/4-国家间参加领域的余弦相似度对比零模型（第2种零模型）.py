import pandas as pd
import numpy as np
import os
from Loader import loader
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl
from matplotlib.colors import LogNorm, LinearSegmentedColormap
from tqdm import tqdm


# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14


# 国家重新选择组织，随机种子可以设定以保证结果的可复现：
# 1、领域优先的选择逻辑：首先为每个国家随机选择1个领域,然后从该领域中随机挑选组织
# 2、数据结构优化：预先建立领域到组织的映射字典field_to_orgs，提高查询效率
# 3、容错处理：当候选组织不足时，从所有组织中补充选择，确保每个国家能分配到足够数量的组织
# 4、随机性控制：仍然保留随机种子参数，保证结果可复现

#  这样的话，每个国家会优先选择那些涉及领域多的组织

def generate_new_matrix(matrix, data, seed=None):
    num_countries, num_organizations = matrix.shape
    country_counts = np.sum(matrix, axis=1)  # 统计每个国家加入组织的总数

    # 设置随机数生成器的种子
    if seed is not None:
        np.random.seed(seed)

    # 创建新矩阵
    new_matrix = np.zeros((num_countries, num_organizations), dtype=int)

    # 预计算每个领域包含的组织索引
    field_to_orgs = {field: [] for field in range(0, 11)}  # 0、1、2、……、10
    for org_idx in range(num_organizations):
        fields = data.loc[org_idx, 'field']
        for field in fields:
            field_to_orgs[field].append(org_idx)  #0、1、2、……、10共11个领域，其中0代表不属于10个领域的组织

    # 随机分配组织
    for country_idx in tqdm(range(num_countries), desc="Processing countries"):
        remaining_orgs = country_counts[country_idx]
        selected_orgs_set = set()
        available_fields = list(field_to_orgs.keys())  # 可用的领域列表0、1、2、……、10共11个


        while remaining_orgs > 0 and available_fields:
            # 随机选择一个领域
            selected_field = np.random.choice(available_fields)

            # 获取可用组织
            available_orgs = [org for org in field_to_orgs[selected_field] if org not in selected_orgs_set]

            if available_orgs:
                chosen_org = np.random.choice(available_orgs)
                new_matrix[country_idx, chosen_org] = 1
                selected_orgs_set.add(chosen_org)
                remaining_orgs -= 1
            else:
                # 从可用领域中移除该领域
                available_fields.remove(selected_field)


        if remaining_orgs > 0:
            print("没有满足，从全部组织中再选")
            all_orgs = list(range(num_organizations))
            available_all_orgs = [org for org in all_orgs if org not in selected_orgs_set]
            chosen_org = np.random.choice(available_all_orgs, size= remaining_orgs, replace=False)
            new_matrix[country_idx, chosen_org] = 1


    return new_matrix





# 定义余弦相似度函数
def cosine_similarity(vec1, vec2):
    dot_product = np.dot(vec1, vec2)
    norm_vec1 = np.linalg.norm(vec1)
    norm_vec2 = np.linalg.norm(vec2)
    if norm_vec1 == 0 or norm_vec2 == 0:
        return 0  # 如果某个向量全为 0，返回 0
    return dot_product / (norm_vec1 * norm_vec2)





# 1至97个主题到领域的划分,有个别主题没有划分到这10个领域中 【有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0】
field1 = [21, 38, 52, 53, 54, 57, 68, 73, 88]
field2 = [8, 11, 12, 14, 18, 20, 30, 32, 40, 47, 50, 51, 67, 69]
field3 = [1, 4, 7, 27, 42, 46, 64]
field4 = [24, 33, 35, 41, 43, 44, 59, 61, 71, 89]
field5 = [15, 39, 48, 58, 66, 80, 81, 82, 83, 84, 87, 90, 91, 92, 93, 94, 95, 96, 97]
field6 = [3, 6, 17, 23, 36, 55, 60, 78, 79, 85, 86]
field7 = [13, 16, 19, 29, 31, 37, 45, 56, 72, 75, 76]
field8 = [10, 63, 26, 30]
field9 = [62, 74]
field10 = [5, 25, 34]




# 1、加载数据，转为国家与组织的关联矩阵------------------------------------------------------------------------------------------------------------
data = pd.read_json('org.json', encoding="utf-8")
subject = data['主题序号']
edgeNum = data.shape[0] #组织的数量
field0 = []


for i in range(edgeNum):
    if subject[i] != None:  #第146个组织Bonsucro没有主题
        numbers = subject[i].split() #以空格分隔
        numbers_list = [int(num) for num in numbers] #转为整型列表
        subject_index = [index+1 for index, value in enumerate(numbers_list) if value != 0]  #该组织所属主题的序号1至97
        field_index = [] #由主题序号进一步判断该组织所属领域
        if bool(set(subject_index) & set(field1)): #两个集合有交集True
            field_index.extend([1])
        if bool(set(subject_index) & set(field2)):
            field_index.extend([2])
        if bool(set(subject_index) & set(field3)):
            field_index.extend([3])
        if bool(set(subject_index) & set(field4)):
            field_index.extend([4])
        if bool(set(subject_index) & set(field5)):
            field_index.extend([5])
        if bool(set(subject_index) & set(field6)):
            field_index.extend([6])
        if bool(set(subject_index) & set(field7)):
            field_index.extend([7])
        if bool(set(subject_index) & set(field8)):
            field_index.extend([8])
        if bool(set(subject_index) & set(field9)):
            field_index.extend([9])
        if bool(set(subject_index) & set(field10)):
            field_index.extend([10])
        # 因为有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0，后续不进行统计了
        if field_index != []:
            field0.append(field_index)
        else:
            field0.append([0])
    else:
        field0.append([0])

data['field'] = field0  # 添加领域信息





# 2、统计每个国家参与每个领域的组织数量---------------------------------------------------------------------------------------------------------------------------
num_countries = 193 # 国家数量
num_fields = 11  # 领域数量

country_field_matrix = np.zeros((num_countries, num_fields), dtype=int)  # 193 行 × 11 列

for idx, row in data.iterrows():  #迭代data的每一行
    country = row['Nation_Member_Index']  # 获取组织包含国家的字符串
    fields = row['field']  # 获取组织所属领域的列表

    # 将字符串转为国家下标索引
    if country.strip():  # 检查字符串是否为空
        country_index = list(map(int, country.split()))
    else:
        country_index = []  # 如果为空，设置为空列表

    # 更新矩阵
    for field in fields:
        country_field_matrix[country_index, field] += 1  # 领域从 0 开始，矩阵索引从 0 开始





# 3、计算当前各国之间在10个领域上的余弦相似性---------------------------------------------------------------------------------------------------------------------------
cosine_similarity_matrix = np.zeros((193, 193))
for i in range(193):
    for j in range(193):
        cosine_similarity_matrix[i, j] = cosine_similarity(country_field_matrix[i, 1:11]/sum(country_field_matrix[i, 1:11]), country_field_matrix[j, 1:11]/(country_field_matrix[j, 1:11]))




# 4、当前国家和组织的关联矩阵 matrix，并进行打乱形成新的矩阵---------------------------------------------------------------------------------------------------------------------------
path = 'node_edge_matrix.txt'
hyperGraph = loader(path) # Hyper_graph为dataloader类的一个实例，这里调用这个类中的方法
hyperGraph.load()
matrix = hyperGraph.hyper_matrix.values # 193个节点和所有超边的关联矩阵
aaa = np.sum(matrix, axis=1)


# 新划分后的矩阵
new_matrix = generate_new_matrix(matrix, data, seed=1001)
bbb = np.sum(new_matrix, axis=1)




# 5、统计新划分的每个国家参与每个领域的组织数量---------------------------------------------------------------------------------------------------------------------------
# 初始化统计矩阵
new_country_field_matrix = np.zeros((num_countries, num_fields), dtype=int)  # 193 行 × 11 列




# 遍历new_matrix
for country_idx in range(num_countries):
    for org_idx in range(new_matrix.shape[1]):
        if new_matrix[country_idx, org_idx] == 1:  # 如果国家 country_idx 参与了组织 org_idx
            fieldss = data.loc[org_idx, 'field']  # 获取组织 org_idx 的领域列表
            for field in fieldss:
                new_country_field_matrix[country_idx, field] += 1  # 更新统计矩阵。  领域从 0开始，矩阵索引从 0 开始



ccc = np.sum(country_field_matrix, axis=1)
ddd = np.sum(new_country_field_matrix, axis=1)



# 6、计算新划分的各国之间在10个领域上的余弦相似性---------------------------------------------------------------------------------------------------------------------------
new_cosine_similarity_matrix = np.zeros((193, 193))
for i in range(193):
    for j in range(193):
        new_cosine_similarity_matrix[i, j] = cosine_similarity(new_country_field_matrix[i, 1:11]/sum((new_country_field_matrix[i, 1:11])), new_country_field_matrix[j, 1:11]/sum(new_country_field_matrix[j, 1:11]))






# 7、将 cosine_similarity_matrix 与 new_cosine_similarity_matrix 对应位置相除，并绘制热力图，可以帮助我们直观地比较两个矩阵的差异------------------------------------------------------------------------------------------------------------
# 计算对应位置的比值
ratio_cosine_matrix = np.divide(cosine_similarity_matrix, new_cosine_similarity_matrix, out=np.zeros_like(cosine_similarity_matrix, dtype=float), where=new_cosine_similarity_matrix != 0)


# # 将小于 0.8 的值置为 0
# ratio_cosine_matrix[ratio_cosine_matrix < 0.8] = 0





# 绘制热力图
plt.figure(figsize=(10, 8))
sns.heatmap(ratio_cosine_matrix, cmap='Purples', annot=False, cbar=True,  mask=(ratio_cosine_matrix == 0) | np.isnan(ratio_cosine_matrix))  # 隐藏 0 值和 NaN值。  如果你的数据范围是 [0, 2]，并且你希望颜色在 1 处对称（例如，1 表示中性值，小于 1 和大于 1 分别表示不同的趋势），可以设置 center=1。
plt.title("Ratio of cosine_similarity_matrix to new_cosine_similarity_matrix")
plt.xlabel("Countries (Columns)")
plt.ylabel("Countries (Rows)")

# 保存为 JPG 文件，文件名为领域序号
plt.savefig(f"cosine_similarity_heatmap (第2种零模型).jpg", dpi=300, bbox_inches='tight')




# 实际数据中国家参与不同领域的组织数量
actual_field_counts = np.sum(country_field_matrix, axis=0)
print(actual_field_counts)
# 随机生成数据中国家参与不同领域的组织数量
new_field_counts = np.sum(new_country_field_matrix, axis=0)
print(new_field_counts)
# 绘制柱状图
plt.figure(figsize=(11, 6))
plt.bar(np.arange(11) - 0.2, actual_field_counts, width=0.4, label='Actual', color='blue')
plt.bar(np.arange(11) + 0.2, new_field_counts, width=0.4, label='Random', color='orange')
plt.xticks(np.arange(11), [f'Field {i}' for i in range(11)])
plt.title("Organization Counts per Field")
plt.xlabel("Field")
plt.ylabel("Number of Organizations")
plt.legend()
plt.savefig(f"actual_random_country_field_matrix (第2种零模型).jpg", dpi=300, bbox_inches='tight')

plt.show()





