import pandas as pd
import numpy as np
import os
from Loader import loader
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl
from matplotlib.colors import LogNorm, LinearSegmentedColormap
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch




# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14




# 1至97个主题到领域的划分,有个别主题没有划分到这10个领域中 【有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0】
field1 = [21, 38, 52, 53, 54, 57, 68, 73, 88]
field2 = [8, 11, 12, 14, 18, 20, 30, 32, 40, 47, 50, 51, 67, 69]
field3 = [1, 4, 7, 27, 42, 46, 64]
field4 = [24, 33, 35, 41, 43, 44, 59, 61, 71, 89]
field5 = [15, 39, 48, 58, 66, 80, 81, 82, 83, 84, 87, 90, 91, 92, 93, 94, 95, 96, 97]
field6 = [3, 6, 17, 23, 36, 55, 60, 78, 79, 85, 86]
field7 = [13, 16, 19, 29, 31, 37, 45, 56, 72, 75, 76]
field8 = [10, 63, 26, 30]
field9 = [62, 74]
field10 = [5, 25, 34]





# 1、加载数据，并且添加领域的分类------------------------------------------------------------------------------------------------------------
data = pd.read_json('org.json', encoding="utf-8")
subject = data['主题序号']
edgeNum = data.shape[0] #组织的数量
field = []


for i in range(edgeNum):
    if subject[i] != None:  #第146个组织Bonsucro没有主题
        numbers = subject[i].split() #以空格分隔
        numbers_list = [int(num) for num in numbers] #转为整型列表
        subject_index = [index+1 for index, value in enumerate(numbers_list) if value != 0]  #该组织所属主题的序号1至97
        field_index = [] #由主题序号进一步判断该组织所属领域
        if bool(set(subject_index) & set(field1)): #两个集合有交集True
            field_index.extend([1])
        if bool(set(subject_index) & set(field2)):
            field_index.extend([2])
        if bool(set(subject_index) & set(field3)):
            field_index.extend([3])
        if bool(set(subject_index) & set(field4)):
            field_index.extend([4])
        if bool(set(subject_index) & set(field5)):
            field_index.extend([5])
        if bool(set(subject_index) & set(field6)):
            field_index.extend([6])
        if bool(set(subject_index) & set(field7)):
            field_index.extend([7])
        if bool(set(subject_index) & set(field8)):
            field_index.extend([8])
        if bool(set(subject_index) & set(field9)):
            field_index.extend([9])
        if bool(set(subject_index) & set(field10)):
            field_index.extend([10])
        # 因为有的主题没有划分到10个领域中，所以有的组织没有所属的领域，就直接置为0，后续不进行统计了
        if field_index != []:
            field.append(field_index)
        else:
            field.append([0])
    else:
        field.append([0])

data['field'] = field  # 添加领域信息








# 2、 按领域分组--------------------------------------------------------------------------------------------------------------------------------

for field_id in range(1, 11):
    # 2.1 按领域分组，获取某个领域内的组织和国家
    field_orgs = data[data['field'].apply(lambda x: field_id in x)]  # 获取属于当前领域的组织

    # Nation_Member_Index 是一个 Series，每个元素是一个字符串，包含国家索引下标
    all_country_indices = set()  # 使用集合去重
    for indices_str in field_orgs['Nation_Member_Index']:
        indices = list(map(int, indices_str.split()))  # 将字符串解析为整数列表
        all_country_indices.update(indices)  # 将每个组织的国家索引下标添加到集合中

    # 将 set 转换为有序列表
    all_country_indices = sorted(all_country_indices)



    # 2.2 构建国家和组织之间的关联矩阵  matrix
    orgs = field_orgs.index  # 使用行索引作为组织标识符
    association_matrix = pd.DataFrame(0, index=all_country_indices, columns=orgs)  # 初始化全 0 矩阵

    for idx, row in field_orgs.iterrows():
        org_id = idx  # 使用行索引作为组织标识符
        indices_str = row['Nation_Member_Index']  # 获取该组织的国家索引下标字符串
        country_indices = list(map(int, indices_str.split()))  # 将字符串解析为整数列表
        for country_idx in country_indices:
            association_matrix.loc[country_idx, org_id] = 1  # 如果国家包含组织，则置为 1



    # 2.3 将 association_matrix 转换为 NumPy 矩阵
    matrix = association_matrix.to_numpy()
    num_countries = matrix.shape[0]  #该领域国家的数量
    num_orgs = matrix.shape[1]  #该领域组织的数量



    # 2.4 该领域组织的总数为N，国家i和j实际参与该领域组织的数量为Ni和Nj，则实际中两个国家共同出现在一个该领域组织中的概率为Nij/N。-----------------------------------------------------------
    # 而对于零模型，国家i出现在该领域组织中的概率为Ni/N，国家j出现在组织中的概率为Nj/N，则零模型中两个国家共同出现在一个组织中的概率为（Ni/N）*（Nj/N）。
    # 最后，计算实际与零模型的比值，为(Nij*N)/(Ni*Nj)

    # 可以通过矩阵乘法一次性计算所有国家两两之间的共同组织数量,即矩阵乘以其转置,结果矩阵的第 i 行第 j 列的值就是第 i 个国家和第 j 个国家的共同组织数量。
    common_orgs = np.dot(matrix, matrix.T)

    # 对每一行求和，即可获得每个国家加入的国际组织数量
    org_counts = np.sum(matrix, axis=1)

    ratio_jaccard_matrix = np.zeros((num_countries, num_countries))  # 存放比值的矩阵
    for i in range(num_countries):
        for j in range(num_countries):
            if i == j:
                ratio_jaccard_matrix[i, j] = 1
            else:
                ratio_jaccard_matrix[i, j] = (common_orgs[i, j] * num_orgs) / (org_counts[i] * org_counts[j])




    # 2.5 计算每一行的Jaccard比值的和，并建立一个DataFrame存储数据
    ratio_row_sums = np.nansum(ratio_jaccard_matrix, axis=1)

    # 将国家下标索引和求和值组合成一个 DataFrame
    result_df = pd.DataFrame({
        'Country Index': np.arange(num_countries),  # 国家下标索引
        'Jaccard Ratio Sum': ratio_row_sums  # 每一行的 Jaccard比值 的和
    })

    # 读取 Nations_Dictionary.txt 文件中的国家名称，并将国家名称添加到 result_df 中
    with open('Nations_Dictionary.txt', 'r', encoding='utf-8') as f:
        nations = [line.strip() for line in f]  # 读取每一行并去除换行符
    result_df['Country Name'] = nations



    # 2.7 按Jaccard比值的和降序排列
    result_df = result_df.sort_values(by='Jaccard Ratio Sum', ascending=False)

    # 输出到Excel文件
    result_df.to_excel(f"jaccard_ratio_row_sums_{field_id}_(按照概率纯计算).xlsx", index=False)  # 保存为 Excel 文件，不包含行索引

    # 创建排序索引（从高到低）
    ratio_sorted_indices = result_df['Country Index'].values

    # 对ratio_jaccard_matrix的行和列按照新的排序顺序重新排列
    sorted_ratio_matrix1 = ratio_jaccard_matrix[ratio_sorted_indices][:, ratio_sorted_indices]

    # 对国家名称也按新顺序排列
    sorted_country_names = result_df['Country Name'].values


    # 2.8 画图的数据以及配色
    # 创建掩码矩阵，只显示左下三角（包括对角线）
    mask1 = np.triu(np.ones_like(sorted_ratio_matrix1, dtype=bool), k=1)  # k=1表示从对角线以上开始掩码

    # 紫色渐变（与原始一致）
    purple_cmap = LinearSegmentedColormap.from_list('custom_purple',
        ['#f7fcfd', '#e0ecf4', '#bfd3e6', '#9ebcda', '#8c96c6', '#a88cc6', '#9e7dbb', '#8a5a9b'])

    # 下三角掩码（左下三角为False，右上三角为True）
    lower_triangle_mask = np.triu(np.ones_like(sorted_ratio_matrix1, dtype=bool), k=1)

    # 需要显示绿色的区域（下三角且值<1）
    green_area = (~lower_triangle_mask) & (sorted_ratio_matrix1 <= 1)
    # 需要显示紫色的区域（下三角且值≥1）
    purple_area = (~lower_triangle_mask) & (sorted_ratio_matrix1 > 1)


    # 2.9 创建画布
    plt.figure(figsize=(12, 10))

    # 绘制橘色背景层（只显示在下三角<1的区域）
    sns.heatmap(np.ones_like(sorted_ratio_matrix1),
                cmap=ListedColormap(['#F5B2A9']),
                annot=False,
                cbar=False,
                mask=~green_area,  # 只显示绿色区域
                square=True)

    # 绘制紫色热力图层（只显示下三角≥1的值）
    heatmap = sns.heatmap(sorted_ratio_matrix1,
                          cmap=purple_cmap,
                          annot=False,
                          cbar=True,
                          cbar_kws={"shrink": 0.95, "aspect": 30},  # 使colorbar更细
                          mask=~purple_area,  # 只显示紫色区域
                          norm=LogNorm(vmin=1, vmax=np.nanmax(sorted_ratio_matrix1)),
                          square=True)

    # 添加图例
    legend_elements = [
        Patch(facecolor='#F5B2A9', edgecolor='k', label='Ratio ≤ 1'),
        Patch(facecolor='#9ebcda', edgecolor='k', label='1 < Ratio ≤ 10'),
        Patch(facecolor='#a88cc6', edgecolor='k', label='Ratio > 10')
    ]

    # 创建图例并调整大小
    legend = plt.legend(
        handles=legend_elements,
        bbox_to_anchor=(0.8, 0.995),
        loc='upper left',
        handlelength=0.8,  # 控制色块长度（默认1.0）
        handleheight=0.8,  # 控制色块高度（默认1.0）
        borderaxespad=0.3  # 控制图例与边界的距离
    )

    # 设置坐标轴标签
    tick_count = 5
    plt.xticks(np.arange(0, 193, tick_count), sorted_country_names[::tick_count], rotation=90)
    plt.yticks(np.arange(0, 193, tick_count), sorted_country_names[::tick_count], rotation=0)
    plt.xlabel("Countries")
    plt.ylabel("Countries")



    # 2.10 保存为 JPG 文件，文件名为领域序号
    plt.savefig(f"field_{field_id}_heatmap_with_green_lower_triangle(按照概率纯计算).jpg", dpi=300, bbox_inches='tight')












