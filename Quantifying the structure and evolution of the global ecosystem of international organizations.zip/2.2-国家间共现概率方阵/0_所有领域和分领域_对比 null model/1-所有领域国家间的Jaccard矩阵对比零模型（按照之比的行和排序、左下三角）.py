import pandas as pd
import numpy as np
import os
from Loader import loader
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib as mpl
from matplotlib.colors import LogNorm, LinearSegmentedColormap
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.patches import Patch


# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')

mpl.rcParams['font.family'] = 'Times New Roman'
mpl.rcParams['font.size'] = 14


# 国家重新选择组织，随机种子可以设定以保证结果的可复现
def generate_new_matrix(matrix, seed=None):
    num_countries, num_organizations = matrix.shape
    country_counts = np.sum(matrix, axis=1)  # 统计每个国家加入组织的总数

    # 设置随机数生成器的种子
    if seed is not None:
        np.random.seed(seed)

    # 创建新矩阵
    new_matrix0 = np.zeros((num_countries, num_organizations), dtype=int)

    # 随机分配组织
    for i in range(num_countries):
        # 随机选择 country_counts[i] 个组织
        selected_organizations = np.random.choice(num_organizations, size=country_counts[i], replace=False)
        new_matrix0[i, selected_organizations] = 1

    return new_matrix0


# 计算 Jaccard 的函数
def jaccard_similarity(matrix, i, j):   # matrix为国家组织的关联矩阵, i为第一个国家, j为第二个国家，返回这两个国家的Jaccard值
    # 获取两个国家的行向量
    row_i = matrix[i, :]
    row_j = matrix[j, :]

    # 计算交集大小
    intersection = np.sum(np.logical_and(row_i, row_j))

    # 计算并集大小
    union = np.sum(np.logical_or(row_i, row_j))

    # 计算Jaccard系数
    if union == 0:
        return 0  # 避免除以0
    else:
        return intersection / union




# 1、加载数据，转为国家与组织的关联矩阵------------------------------------------------------------------------------------------------------------
path = 'node_edge_matrix.txt'

hyperGraph = loader(path) # Hyper_graph为dataloader类的一个实例，这里调用这个类中的方法
hyperGraph.load()

matrix = hyperGraph.hyper_matrix.values # 193个节点和所有超边的关联矩阵
nodeNum, edgeNum = matrix.shape # 节点数量、超边数量




# 2、计算当前划分下任意两个国家间的Jaccard矩阵------------------------------------------------------------------------------------------------------------
# 任意两个国家间的Jaccard矩阵
jaccard_matrix = np.zeros((nodeNum, nodeNum))
for i in range(nodeNum):
    for j in range(nodeNum):
        jaccard_matrix[i, j] = jaccard_similarity(matrix, i, j)



# !!!! 计算国家的排名，来对比哪个国家更愿意更别人玩。
# 计算每一行的Jaccard值之和
row_sums = np.sum(jaccard_matrix, axis=1)  # 对每一行求和


# 将国家下标索引和求和值组合成一个 DataFrame
result_df = pd.DataFrame({
    'Country Index': np.arange(jaccard_matrix.shape[0]),  # 国家下标索引
    'Jaccard Sum': row_sums  # 每一行的 Jaccard 值之和
})

# 读取 Nations_Dictionary.txt 文件中的国家名称，并将国家名称添加到 result_df 中
with open('Nations_Dictionary.txt', 'r', encoding='utf-8') as f:
    nations = [line.strip() for line in f]  # 读取每一行并去除换行符
result_df['Country Name'] = nations

# 按Jaccard值之和降序排列
result_df = result_df.sort_values(by='Jaccard Sum', ascending=False)



# 输出到Excel文件
result_df.to_excel(f"jaccard_row_sums_all.xlsx", index=False)  # 保存为 Excel 文件，不包含行索引






# 3、只保证每个国家加入的组织数量不变，但并不保证每个组织的规模不变，使国家进行重新选择------------------------------------------------------------------------------------------------------------
# 新的矩阵
new_matrix = generate_new_matrix(matrix, seed=10)

# 再次计算新划分下的任意两个国家间的Jaccard矩阵
new_jaccard_matrix = np.zeros((nodeNum, nodeNum))
for i in range(nodeNum):
    for j in range(nodeNum):
        new_jaccard_matrix[i, j] = jaccard_similarity(new_matrix, i, j)





# 4、将 jaccard_matrix 与 new_jaccard_matrix 对应位置相除，并绘制热力图，可以帮助我们直观地比较两个矩阵的差异------------------------------------------------------------------------------------------------------------
# 计算对应位置的比值
ratio_jaccard_matrix = np.divide(jaccard_matrix, new_jaccard_matrix, out=np.zeros_like(jaccard_matrix, dtype=float), where=new_jaccard_matrix != 0)


# # 绘制热力图
# plt.figure(figsize=(10, 8))
# sns.heatmap(ratio_jaccard_matrix, cmap='Purples', annot=False, cbar=True, mask=np.isnan(ratio_jaccard_matrix), norm=LogNorm())   #如果你的数据范围是 [0, 2]，并且你希望颜色在 1 处对称（例如，1 表示中性值，小于 1 和大于 1 分别表示不同的趋势），可以设置 center=1。
# plt.title("Ratio of Original Jaccard Matrix to New Jaccard Matrix")
# plt.xlabel("Countries (Columns)")
# plt.ylabel("Countries (Rows)")
#
# # 保存为 JPG 文件，文件名为领域序号
# plt.savefig(f"field_all_heatmap.jpg", dpi=300, bbox_inches='tight')





# 6.1、按照ratio_jaccard_matrix每行之和从高到低排序
# 计算ratio_jaccard_matrix每行之和（忽略nan值）
ratio_row_sums = np.nansum(ratio_jaccard_matrix, axis=1)


# 将国家下标索引和求和值组合成一个 DataFrame
result_df1 = pd.DataFrame({
    'Country Index': np.arange(jaccard_matrix.shape[0]),  # 国家下标索引
    'Jaccard Ratio Sum': ratio_row_sums # 每一行的 Jaccard 值之和
})

# 读取 Nations_Dictionary.txt 文件中的国家名称，并将国家名称添加到 result_df 中
with open('Nations_Dictionary.txt', 'r', encoding='utf-8') as f:
    nations = [line.strip() for line in f]  # 读取每一行并去除换行符
result_df1['Country Name'] = nations


# 按Jaccard Ratio值之和降序排列
result_df1 = result_df1.sort_values(by='Jaccard Ratio Sum', ascending=False)


# 输出到Excel文件
result_df1.to_excel(f"jaccard_ratio_row_sums_all.xlsx", index=False)  # 保存为 Excel 文件，不包含行索引


# 创建排序索引（从高到低）
ratio_sorted_indices = result_df1['Country Index'].values


# 对ratio_jaccard_matrix的行和列按照新的排序顺序重新排列
sorted_ratio_matrix1 = ratio_jaccard_matrix[ratio_sorted_indices][:, ratio_sorted_indices]

# 对国家名称也按新顺序排列
sorted_country_names = result_df1['Country Name'].values

# # 创建掩码矩阵，只显示左下三角（包括对角线）
mask1 = np.triu(np.ones_like(sorted_ratio_matrix1, dtype=bool), k=1)  # k=1表示从对角线以上开始掩码
# cmap1 = LinearSegmentedColormap.from_list('custom_purple', ['#f7fcfd', '#e0ecf4', '#bfd3e6', '#9ebcda', '#8c96c6', '#8c6bb1', '#88419d', '#810f7c'])
# plt.figure(figsize=(12, 10))
# sns.heatmap(sorted_ratio_matrix1,  cmap=cmap1, annot=False, cbar=True, mask=mask1, norm=LogNorm())
#
# # 设置坐标轴标签
# tick_count = 5
# plt.xticks(np.arange(0, nodeNum, tick_count), sorted_country_names[::tick_count], rotation=90)
# plt.yticks(np.arange(0, nodeNum, tick_count), sorted_country_names[::tick_count], rotation=0)
# plt.xlabel("Countries")
# plt.ylabel("Countries")
# plt.savefig("field_all_heatmap_ratio_sorted————.jpg", dpi=300, bbox_inches='tight')









#紫色渐变（与原始一致）
purple_cmap = LinearSegmentedColormap.from_list('custom_purple',
    ['#f7fcfd', '#e0ecf4', '#bfd3e6', '#9ebcda', '#8c96c6', '#a88cc6', '#9e7dbb', '#8a5a9b'])


# purple_cmap = LinearSegmentedColormap.from_list('light_purple',
#     ['#f7fcfd',   # 最浅色（保持）
#      '#e0ecf4',   #
#      '#bfd3e6',   #
#      '#9ebcda',   #
#      '#8c96c6',   # 开始调整紫色
#      '#b89acf',   # 原#a88cc6 → 调亮+增加红调
#      '#b08dc8',   # 原#9e7dbb → 调亮
#      '#9d6ba6'])  # 原#8a5a9b → 调亮

# 1. 准备数据
# 下三角掩码（左下三角为False，右上三角为True）
lower_triangle_mask = np.triu(np.ones_like(sorted_ratio_matrix1, dtype=bool), k=1)

# 需要显示绿色的区域（下三角且值<1）
green_area = (~lower_triangle_mask) & (sorted_ratio_matrix1 <= 1)

# 需要显示紫色的区域（下三角且值≥1）
purple_area = (~lower_triangle_mask) & (sorted_ratio_matrix1 > 1)

# 2. 创建画布
plt.figure(figsize=(12, 10))

# 3. 绘制橘色背景层（只显示在下三角<1的区域）
sns.heatmap(np.ones_like(sorted_ratio_matrix1),
            cmap=ListedColormap(['#F5B2A9']),
            annot=False,
            cbar=False,
            mask=~green_area,  # 只显示绿色区域
            square=True)

# 4. 绘制紫色热力图层（只显示下三角≥1的值）
heatmap = sns.heatmap(sorted_ratio_matrix1,
                      cmap=purple_cmap,
                      annot=False,
                      cbar=True,
                      cbar_kws={"shrink": 0.95, "aspect": 30},  # 使colorbar更细
                      mask=~purple_area,  # 只显示紫色区域
                      norm=LogNorm(vmin=1, vmax=np.nanmax(sorted_ratio_matrix1)),
                      square=True)

# 5. 添加图例
legend_elements = [
    Patch(facecolor='#F5B2A9', edgecolor='k', label='Ratio ≤ 1'),
    Patch(facecolor='#9ebcda', edgecolor='k', label='1 < Ratio ≤ 10'),
    Patch(facecolor='#a88cc6', edgecolor='k', label='Ratio > 10')
]

# 创建图例并调整大小
legend = plt.legend(
    handles=legend_elements,
    bbox_to_anchor=(0.8, 0.995),
    loc='upper left',
    handlelength=0.8,  # 控制色块长度（默认1.0）
    handleheight=0.8,  # 控制色块高度（默认1.0）
    borderaxespad=0.3  # 控制图例与边界的距离
)


# 6. 设置坐标轴标签
tick_count = 5
plt.xticks(np.arange(0, nodeNum, tick_count), sorted_country_names[::tick_count], rotation=90)
plt.yticks(np.arange(0, nodeNum, tick_count), sorted_country_names[::tick_count], rotation=0)
plt.xlabel("Countries")
plt.ylabel("Countries")



# 7. 保存图像
plt.savefig("field_all_heatmap_with_green_lower_triangle.jpg",dpi=300,bbox_inches='tight')


