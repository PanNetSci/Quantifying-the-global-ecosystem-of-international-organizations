import pandas as pd
import numpy as np
import seaborn as sns
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.colors as mcolors


# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')



mpl.rcParams['font.family'] = 'Times New Roman' 
mpl.rcParams['font.size'] = 42



with open('Nations_Dictionary.txt', "r", encoding="utf-8") as file:
    Nations_lines = file.readlines()
    Nations_lines = [i.strip() for i in Nations_lines]


data = pd.read_csv('C:/Users/panqingtao/Desktop/国际组织分析/2-爬取的数据/程序/0-支撑材料/0-【数据处理】/4-任意国家在任意年每个领域的共现矩阵/共现概率矩阵/2024_All.csv', header = None)
data1 = pd.read_excel(r'1-国家参与的组织数量.xlsx')
nation_org_num = list(data1['all'])
data['number'] = nation_org_num


sorted_index = data.sort_values(by='number', ascending = False).index
sorted_data = data.iloc[sorted_index, sorted_index]
df_countries_name = pd.read_csv('国家的简称.csv', encoding='GBK')
countries_name = np.array(df_countries_name['简称'])[sorted_index] # 添加名称
sorted_data.index = countries_name
sorted_data.columns = countries_name



# 绘图
# 制作一个colorbar
my_colorbar = mcolors.LinearSegmentedColormap.from_list('',['#9CBEE0', '#F9F9F9', '#C9A1CA'])
# my_blue = mcolors.LinearSegmentedColormap.from_list('my_blue',['#FFFFFF', '#5AB2CE'])
#    #9ED2E2 欧洲   #EDE277 亚洲  #CFA8D0 北美  #D67474 南美  #F8B072 非洲 #B7DBBE 大洋洲

plt.figure(figsize=(9, 7.6))  # 设置图形的大小
ax = sns.heatmap(sorted_data, annot = False, cmap = my_colorbar, norm = mcolors.LogNorm(0.015), alpha = 1)  # fmt='d' 表示整数格式
cbar = ax.collections[0].colorbar
cbar.ax.tick_params(labelsize=38)

# inter = 20
# ticks = list(range(193))[::inter]
# labels = list(sorted_data.index)[::inter]
# ax.set_xticks(ticks, labels)
# ax.set_yticks(ticks, labels)




# 设置刻度位置和标签（每隔20个显示一个数值）
inter = 30  # 间隔20个显示一个标签
ticks = list(range(0, 193, inter))  # 刻度位置
labels = [str(i) for i in range(0, 193, inter)]  # 对应的标签

ax.set_xticks(ticks)
ax.set_yticks(ticks)
ax.set_xticklabels(labels, fontsize=38)  # 调整字体大小
ax.set_yticklabels(labels, fontsize=38)



# # 移除所有刻度线（ticks）
# ax.tick_params(
#     axis='both',          # 同时作用于 x 和 y 轴
#     which='both',         # 同时影响主刻度和次刻度
#     length=0,             # 刻度线长度设为 0（即不显示）
#     bottom=False,         # 移除底部刻度线（X轴）
#     left=False,           # 移除左侧刻度线（Y轴）
# )

# 隐藏所有刻度标签
# ax.set_xticklabels([])
# ax.set_yticklabels([])
# 在X轴和Y轴的中心位置添加"Country"标签
ax.set_xlabel("Country rank", fontsize=38)  # labelpad调整标签与轴的距离
ax.set_ylabel("Country rank", fontsize=38)


plt.savefig('Main改.jpg', dpi = 330, bbox_inches='tight')


plt.show()