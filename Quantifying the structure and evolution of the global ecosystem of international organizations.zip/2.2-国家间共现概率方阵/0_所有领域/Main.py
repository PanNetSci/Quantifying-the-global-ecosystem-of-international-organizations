import pandas as pd
import numpy as np
import seaborn as sns
from tqdm import tqdm
import matplotlib.pyplot as plt
import matplotlib as mpl
import matplotlib.colors as mcolors

mpl.rcParams['font.family'] = 'Times New Roman' 
mpl.rcParams['font.size'] = 42



with open('Nations_Dictionary.txt', "r", encoding="utf-8") as file:
    Nations_lines = file.readlines()
    Nations_lines = [i.strip() for i in Nations_lines]


data = pd.read_csv('C:/Users/86442/Desktop/1-国际组织研究-组织容纳度规律/0-支撑材料/0-【数据处理】/4-任意国家在任意年每个领域的共现矩阵/共现概率矩阵/2024_All.csv', header = None)
data1 = pd.read_excel(r'1-国家参与的组织数量.xlsx')
nation_org_num = list(data1['all'])
data['number'] = nation_org_num


sorted_index = data.sort_values(by='number', ascending = False).index
sorted_data = data.iloc[sorted_index, sorted_index]
df_countries_name = pd.read_csv('国家的简称.csv', encoding='GBK')
countries_name = np.array(df_countries_name['简称'])[sorted_index] # 添加名称
sorted_data.index = countries_name
sorted_data.columns = countries_name



# 绘图
# 制作一个colorbar
my_colorbar = mcolors.LinearSegmentedColormap.from_list('',['#9CBEE0', '#F9F9F9', '#C9A1CA'])
# my_blue = mcolors.LinearSegmentedColormap.from_list('my_blue',['#FFFFFF', '#5AB2CE'])
#    #9ED2E2 欧洲   #EDE277 亚洲  #CFA8D0 北美  #D67474 南美  #F8B072 非洲 #B7DBBE 大洋洲

plt.figure(figsize=(10.4, 8.7), constrained_layout = True)  # 设置图形的大小
ax = sns.heatmap(sorted_data, annot = False, cmap = my_colorbar, norm = mcolors.LogNorm(0.015), alpha = 1)  # fmt='d' 表示整数格式
cbar = ax.collections[0].colorbar
cbar.ax.tick_params(labelsize=35)

inter = 20
ticks = list(range(193))[::inter]
labels = list(sorted_data.index)[::inter]
ax.set_xticks(ticks, labels)
ax.set_yticks(ticks, labels)

plt.savefig('Main.jpg', dpi = 900)


plt.show()