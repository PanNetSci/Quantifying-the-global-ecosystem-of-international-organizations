import pandas as pd
import numpy as np
import seaborn as sns 
from scipy.stats import norm
import matplotlib.pyplot as plt 
from scipy.optimize import curve_fit
import matplotlib as mpl  


# 如果你的代码中没有显式设置后端，可以尝试在程序开头添加以下代码来设置 Matplotlib 的后端
import matplotlib
matplotlib.use('TkAgg')



# 定义拟合函数（高斯分布PDF的简化版）  
def norm_f(x, mean, std):
    return norm.pdf(x, mean, std)

mpl.rcParams['font.family'] = 'Times New Roman'  # 注意：这可能在某些系统上不起作用  
mpl.rcParams['font.size'] = 30 
  
# 1、数据处理
data = pd.read_excel('Data.xlsx', index_col = 0)
scale_list = [[] for _ in range(10)]

field_label =  ['Technology and Engineering', 
               'Society and Policy', 
               'Religion and Culture', 
               'Education and Research', 
               'Resource and Environment', 
               'Health and Wellbeing', 
               'Economy and Development', 
               'Defense and Security',
               'Sport and Entertainment ', 
               'Art and Design']

# field_label =  ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']

colors = [
'#82B0D2',
'#E25C5C',
'#FFB061',
'#BECFC9',
'#C1DE9C',
'#E7DAD2',
'#BEB8DC',
'#999999',
'#F3D266',
'#F6CAE5']

field_list = [
'科技与工程', 
'社会与政策',
'宗教与文化',
'教育与研究',
'资源与环境',
'健康与福祉',
'经济与发展',
'国防与安全',
'体育与娱乐',
'艺术与设计',
]
# 先获得规模
for i in range(len(data)):
    i_field = data.loc[i, 'Field']
    i_scale = data.loc[i, 'Scale']
    index = field_list.index(i_field)
    scale_list[index].append(i_scale)
# 统计每种规模出现的概率
real_result = pd.DataFrame(0, index = range(10), columns = range(1, 194))
n, m = real_result.shape
for i in range(n):
    for j in range(m):
        real_result.iloc[i, j] = scale_list[i].count(j+1)
real_result_value = real_result.copy()

for i in range(n):
    i_sum = real_result.iloc[i, :].sum()
    for j in range(m):
        real_result_value.iloc[i, j] = real_result.iloc[i, j] / i_sum

# 2、图形绘制
fig = plt.figure(figsize=(15, 8))

for i in range(10):
    # 1、绘制分箱散点图
    i_data = scale_list[i]
    min_value = min(i_data)
    max_value = max(i_data)
    counts, bins = np.histogram(i_data, bins=np.logspace(np.log10(min_value), np.log10(max_value), 100, base = 10))
    bin_centers = (bins[:-1] + bins[1:]) / 2
    pdf = counts / sum(counts)
    plt.scatter(bin_centers, pdf, alpha = 1, zorder = -1, label = field_label[i], color = colors[i])


plt.xlabel('Scale')
plt.ylabel('Frequency')
plt.legend(loc='upper right', ncol = 2, fontsize = 21)
# plt.show()
plt.savefig('Main.png', dpi = 400, bbox_inches = 'tight')