import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib as mpl

mpl.rcParams['font.family'] = 'Times New Roman' 
mpl.rcParams['font.size'] = 42

my_blue = mcolors.LinearSegmentedColormap.from_list('my_blue',['#FFFFFF', '#A7CBE3'])
colors = my_blue(np.linspace(0.07, 0.9, 6))[::-1]


org_scales = np.array(pd.read_excel('HEdgeALL.xlsx', sheet_name = 'Sheet1').iloc[:, 0])
org_num = len(org_scales)
frequency_data = np.zeros(193)
for i in range(193):
    frequency_data[i] = len(np.where(org_scales == (i+1))[0])/org_num
    
# 多项式拟合曲线
n = 3
x_fit = list(range(1, 194))[n:]
y_fit = frequency_data[n:]
p = np.polyfit(x_fit, y_fit, 6)

# 绘图
x_plot = range(1, 194)
# 图像大小
fig, ax = plt.subplots(figsize=(15, 7.3), constrained_layout = True)
inter = 1

# plt.scatter(x_plot[1::inter], frequency_data[1::inter], s = 100, fc = 'None', ec = 'tab:grey', lw = 2, alpha = 1, label = 'Actual distribution')  # 字号12


labels = ['small', 'middle', 'big', 'very big']
interval = [2, 33.8, 65.7, 97.5, 129.3, 161.2, 193]
for i in range(6):
    x_min = interval[i]
    x_max = interval[i+1]
    x_curve = np.linspace(x_min, x_max, 100)
    y_curve = np.polyval(p, x_curve)
    plt.fill_between(x_curve, -0.005, y_curve, label = '%.1f-%.1f'%(x_min, x_max), color = colors[i], ec = 'None', zorder = -2)
    if i == 5:
        plt.plot(x_curve, y_curve, lw = 4, color = '#9ACEA3', label = 'Trend line', alpha = 1, zorder = -1)  # 字号12
    else:
        plt.plot(x_curve, y_curve, lw = 4, color = '#9ACEA3', alpha = 1, zorder = -1)  # 字号12

plt.scatter(x_plot[1::inter], frequency_data[1::inter], s = 70, alpha = 0.6, label = 'Actual distribution', color = '#CEA8D1')  # 字号12 
    
# plt.legend(bbox_to_anchor = (0.97, 1))
plt.legend(fontsize = 35, ncol = 2)
plt.ylim(-0.005,)
inter = 4
plt.xlim(1-inter, 193+inter)
plt.xlabel('Scale', fontsize = 45)
plt.ylabel('Frequency', fontsize = 45)
plt.savefig('Main.jpg', dpi = 900)