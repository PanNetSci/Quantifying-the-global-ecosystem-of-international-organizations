import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import seaborn as sns
from tqdm import tqdm
import matplotlib as mpl
import matplotlib.colors as mcolors

mpl.rcParams['font.family'] = 'Times New Roman' 
mpl.rcParams['font.size'] = 50

with open('Nations_Dictionary.txt', "r", encoding="utf-8") as file:
    Nations_lines = file.readlines()
    Nations_lines = [i.strip() for i in Nations_lines]

df_countries_name = pd.read_csv('国家的简称.csv', encoding='GBK')
countries_name = list(df_countries_name['简称']) # 添加名称

fields_name =  [ 'All',
            'Technology and Engineering', 
            'Society and Policy', 
            'Religion and Culture', 
            'Education and Research', 
            'Resource and Environment', 
            'Health and Wellbeing', 
            'Economy and Development', 
            'Defence and Security', 
            'Sport and Entertainment ', 
            'Art and Design']

fields_name =  ['TE','SP','RC','ER','RE','HW','ED','DS','SE','AD']

fields = [str(x) for x in range(10)]
# fields = ['All']

def get_data(year, field, i, j):
    basic_path = 'C:/Users/86442/Desktop/1-国际组织研究-组织容纳度规律/0-【数据处理】/4-任意国家在任意年每个领域的共现矩阵/共现概率矩阵/%s_%s.csv'%(year, field)
    data = pd.read_csv(basic_path, header=None)
    return data.iloc[i, j]

def get_nation_avg(year, field):
    basic_path = 'C:/Users/86442/Desktop/1-国际组织研究-组织容纳度规律/0-【数据处理】/4-任意国家在任意年每个领域的共现矩阵/共现概率矩阵/%s_%s.csv'%(year, field)
    data = pd.read_csv(basic_path, header=None)
    data_sum = data.sum(axis = 0)
    data_avg = (data_sum - 1)/192
    
    return data_avg


my_colorbar = mcolors.LinearSegmentedColormap.from_list('',['#9CBEE0', '#F9F9F9', '#C9A1CA'])
my_norm = mcolors.LogNorm(vmin = 10 ** (-1), vmax = 10 ** (-0.4), clip = True)

for f in tqdm(range(len(fields))):
    field = fields[f]
    field_name = fields_name[f]
    year = range(1900, 2025)
    df = pd.DataFrame(0, index = countries_name, columns = year)
    for y in year:
        year_data = get_nation_avg(y, field)
        df.loc[:, y] = list(year_data)
    
    # 2、排序
    df['RowSum'] = df.apply(lambda row: row.sum(), axis=1)  
    # 根据'RowSum'列进行排序  
    df_sorted = df.sort_values(by='RowSum', ascending = False) 
    df_sorted = df_sorted.iloc[:, :-1]
    
    # print(df_sorted.max().max(), df_sorted.min().min())


    # 2、绘图
    n = 1.5
    fig, ax = plt.subplots(figsize=(18 * n, 6.6 * n))  # 设置图形的大小
    sns.heatmap(df_sorted, cmap = my_colorbar, norm = my_norm)
    
    x_inter = 10
    xticks = np.array(list(range(125))[::x_inter]) + 0.5
    xticks_labels = list(range(1900, 2025))[::x_inter]
    
    y_inter = 25
    yticks = np.array(list(range(193))[::y_inter]) + 0.5
    yticks_labels = list(df_sorted.index)[::y_inter]
    
    ax.set_xticks(xticks, xticks_labels)
    ax.set_yticks(yticks, yticks_labels)
    
    # label_year = [1924, 1945, 1991]
    # for y in label_year:
    #     ax.axvline(0.5 + y - 1900, color='tab:grey', lw = 2, linestyle=(0, (5, 5)))
    #     ax.text(0.5 + y - 1900, -5, y, ha = 'center', va = 'center')
    
    plt.savefig('./figs/%s.jpg'%field_name, dpi = 400, bbox_inches = 'tight')
    plt.show()
    plt.close()
    
    # break
    
# label_year = [1924, 1933, 1945, 1960, 1991]
# for y in label_year:
#     ax.axvline(0.5 + y - 1900, color='tab:grey', lw = 2, linestyle=(0, (5, 5)))
#     ax.text(0.5 + y - 1900, -5, y, ha = 'center', va = 'center')




    
    
    