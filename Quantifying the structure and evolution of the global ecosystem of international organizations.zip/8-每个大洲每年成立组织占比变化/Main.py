import pandas as pd
import numpy as np
import matplotlib.pyplot as plt 
import matplotlib as mpl 
from matplotlib.ticker import FuncFormatter 

def to_percent(y, position):  
    # Ignore the passed in position. This has the effect of suppressing ticks  
    s = '{:.0f}%'.format(100 * y)  
    return s  

mpl.rcParams['font.family'] = 'Times New Roman'  # 注意：这可能在某些系统上不起作用  
mpl.rcParams['font.size'] = 42 

data = pd.read_excel('总部在各个大洲组织每年成立数量.xlsx', index_col = 0)
data = data.iloc[np.array([2, 0, 1, 4, 3, 5]), :]

Colors = ['#F8B072', '#EDE277', '#9ED2E2', '#CFA8D0', '#B7DBBE', '#D67474']

data_per = data.apply(lambda x: x / x.sum(), axis=0) 
data_per_cum = data_per.cumsum(axis = 0)
continents = ['Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America']


# 绘制图像
fig, ax = plt.subplots(figsize = (15, 8.5), constrained_layout = True) 
x_plot = data_per.columns

width = 0.7
alpha = 0.5
for i in range(6):
    if i == 0:
        ax.bar(x_plot, data_per.iloc[i, :], width, label = continents[i], color = Colors[i], alpha = alpha)  
    else:
        ax.bar(x_plot, data_per.iloc[i, :], width, bottom = data_per_cum.iloc[i-1, :], label = continents[i], color = Colors[i], alpha = alpha)  


plt.xlim(1898, 2025)
ax.yaxis.set_major_formatter(FuncFormatter(to_percent))
ax.set_yticks([0.2,0.4,0.6,0.8,1])
plt.legend(fontsize = 30, bbox_to_anchor=(0.99, 0.48), loc = 'center right', ncol = 2)
plt.ylabel('Percentage', fontsize = 45) 
plt.xlabel('Year', fontsize = 45)
plt.savefig('Main.jpg', dpi = 900)