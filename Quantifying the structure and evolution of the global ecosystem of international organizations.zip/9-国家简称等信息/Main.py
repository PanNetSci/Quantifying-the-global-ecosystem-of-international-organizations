import pandas as pd
import numpy as np

file_path = "Nations_Dictionary.txt"  # 将"文件路径.txt"替换为你的txt文件路径
with open(file_path, "r", encoding="utf-8") as file:
    Nations_lines = file.readlines()
    Nations_lines_raw = [i.strip() for i in Nations_lines]

data = pd.read_excel('Nodes.xlsx').iloc[:, 3:]
data.drop('ID', axis=1, inplace=True)
data['Name'] = Nations_lines_raw

data.to_excel('Data.xlsx')

