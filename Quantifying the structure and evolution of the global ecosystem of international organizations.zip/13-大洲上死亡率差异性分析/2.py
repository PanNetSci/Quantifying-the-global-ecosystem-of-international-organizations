'''
我有一组数据，是国际组织的数据，存储在一个excel中，名称为“最终版所有数据-25268.xlsx”，其中的每行为一个组织的信息，
每个组织的属性包括“成立时间”，“Type1”，“Last_News”，“Nation_Member_Number”，“总部国家”等，
这四个属性分别表示组织成立的年份（整数，可能为空值）、组织的类型（当此属性中出现字母H或J或U时，组织已经死亡，
例如使用orgs_before_year['Type1'].str.contains('H|J|U')）、组织的最后消息年份（整数，对于已经死亡的组织，该年份为组织的死亡时间）、
组织的成员数量、组织的总部国家（国家名称形式）。
我还会提供给你一个excel文件，是每个国家与其大洲的对应，名称为“国家-大洲.xlsx”,列名分别为“Id”和“Continent”,对应国家名称和大洲名称。
现在我需要你帮我做一个事情：统计各个总部国家对应的死亡率，看各大洲上总部国家的死亡率是否有差异?
请你先告诉我你的思路，然后再用代码实现。注意，以上属性信息不一定都能用上，请你仔细辨别
'''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


def load_and_prepare_data(main_file, mapping_file):
    """加载并准备数据"""
    # 加载主数据
    df = pd.read_excel(main_file)
    df['is_dead'] = df['Type1'].str.contains('H|J|U', na=False).astype(int)

    # 加载国家-大洲映射
    country_continent = pd.read_excel(mapping_file)

    return df, country_continent





def merge_continent_data(country_stats, country_continent):
    """合并大洲信息"""
    # # 标准化国家名称
    # country_stats['总部国家'] = country_stats['总部国家'].str.strip()
    # country_continent['Id'] = country_continent['Id'].str.strip()

    # 确保country_continent中的国家列名正确（假设为'Id'）
    country_list = country_continent['Id'].tolist()  # 获取country_continent中的国家列表及顺序

    # 筛选country_stats中存在于country_continent的国家
    filtered_stats = country_stats[country_stats['总部国家'].isin(country_list)].copy()

    # 按照country_continent中的国家顺序排序
    filtered_stats['总部国家'] = pd.Categorical(
        filtered_stats['总部国家'],
        categories=country_list,
        ordered=True
    )
    filtered_stats = filtered_stats.sort_values('总部国家')


    # 合并数据
    merged = pd.merge(
        filtered_stats,
        country_continent,
        left_on='总部国家',
        right_on='Id',
        how='left'
    )

    return merged.dropna(subset=['Continent'])


# def analyze_by_continent(merged_data):
#     """大洲层面的分析"""
#     # 大洲级统计
#     continent_stats = merged_data.groupby('Continent').agg(
#         num_countries=('总部国家', 'nunique'),
#         total_orgs=('total_orgs', 'sum'),
#         avg_mortality=('mortality_rate', 'mean'),
#         median_mortality=('mortality_rate', 'median')
#     ).reset_index()
#
#     # 统计检验 - Kruskal-Wallis检验（非参数ANOVA）
#     groups = []
#     for continent in merged_data['Continent'].unique():
#         groups.append(merged_data[merged_data['Continent'] == continent]['mortality_rate'])
#
#     h_stat, p_value = stats.kruskal(*groups)
#
#     # 如果显著，进行事后检验
#     posthoc = None
#     if p_value < 0.05:
#         posthoc = pairwise_tukeyhsd(
#             endog=merged_data['mortality_rate'],
#             groups=merged_data['Continent'],
#             alpha=0.05
#         )
#
#     return {
#         'continent_stats': continent_stats,
#         'kruskal_test': {'H': h_stat, 'p_value': p_value},
#         'posthoc': posthoc
#     }



def analyze_by_continent(merged_data):
    """大洲层面的分析（简化版）"""
    continent_stats = merged_data.groupby('Continent').agg(
        num_countries=('总部国家', 'nunique'),
        total_orgs=('total_orgs', 'sum'),
        avg_mortality=('mortality_rate', 'mean'),
        median_mortality=('mortality_rate', 'median')
    ).reset_index()

    return {
        'continent_stats': continent_stats,
        'kruskal_test': {'H': None, 'p_value': None},
        'posthoc': None
    }


def visualize_results(merged_data, analysis_results):
    """可视化结果"""
    # 设置图形风格
    sns.set_style("whitegrid")
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

    # 1. 各大洲死亡率对比
    plt.figure(figsize=(12, 6))
    ax = sns.barplot(
        x='Continent',
        y='mortality_rate',
        data=merged_data,
        estimator=np.mean,
        ci=95,
        order=analysis_results['continent_stats'].sort_values('avg_mortality')['Continent'],
        palette="Blues_d"
    )
    plt.title('各大洲平均死亡率比较（95%置信区间）', fontsize=14)
    plt.ylabel('死亡率', fontsize=12)
    plt.xlabel('大洲', fontsize=12)
    plt.xticks(rotation=45)

    # 添加数值标签
    for p in ax.patches:
        ax.annotate(f"{p.get_height():.2%}",
                    (p.get_x() + p.get_width() / 2., p.get_height()),
                    ha='center', va='center',
                    xytext=(0, 10),
                    textcoords='offset points')

    plt.tight_layout()
    plt.show()

    # 2. 死亡率最高/最低的10个国家
    top_countries = merged_data.nlargest(10, 'mortality_rate')
    bottom_countries = merged_data.nsmallest(10, 'mortality_rate')

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))

    sns.barplot(x='mortality_rate', y='总部国家', data=top_countries, ax=ax1, palette="Reds_d")
    ax1.set_title('死亡率最高的10个国家', fontsize=14)
    ax1.set_xlabel('死亡率', fontsize=12)
    ax1.set_ylabel('国家', fontsize=12)

    sns.barplot(x='mortality_rate', y='总部国家', data=bottom_countries, ax=ax2, palette="Greens_d")
    ax2.set_title('死亡率最低的10个国家', fontsize=14)
    ax2.set_xlabel('死亡率', fontsize=12)
    ax2.set_ylabel('')

    # 添加数值标签
    for ax in [ax1, ax2]:
        for p in ax.patches:
            width = p.get_width()
            ax.text(width + 0.01, p.get_y() + p.get_height() / 2.,
                    f"{width:.2%}",
                    ha='left', va='center')

    plt.tight_layout()
    plt.show()

    # 3. 大洲组织数量分布
    plt.figure(figsize=(10, 10))
    continent_counts = merged_data.groupby('Continent')['total_orgs'].sum()
    explode = [0.1 if i == continent_counts.idxmax() else 0 for i in continent_counts.index]

    plt.pie(continent_counts,
            labels=continent_counts.index,
            autopct='%1.1f%%',
            startangle=90,
            explode=explode,
            shadow=True,
            textprops={'fontsize': 12})
    plt.title('各大洲组织数量分布', fontsize=14)
    plt.show()






if __name__ == "__main__":

    # 文件路径 - 根据实际情况修改
    main_file = "最终版所有数据-25268.xlsx"
    mapping_file = "国家-大洲.xlsx"

    # 1. 加载和准备数据
    df, country_continent = load_and_prepare_data(main_file, mapping_file)


    # 2. 按国家计算死亡率
    min_orgs = 0
    country_stats = df.groupby('总部国家').agg(
        total_orgs=('is_dead', 'count'),
        dead_orgs=('is_dead', 'sum')
    ).reset_index()
    # 计算死亡率
    country_stats['mortality_rate'] = country_stats['dead_orgs'] / country_stats['total_orgs']
    # 过滤样本量过少的国家
    country_stats = country_stats[country_stats['total_orgs'] >= min_orgs]

    # # 确保country_continent中的国家列名正确（假设为'Id'）
    # country_list = country_continent['Id'].tolist()  # 获取country_continent中的国家列表及顺序
    # # 筛选country_stats中存在于country_continent的国家
    # filtered_stats = country_stats[country_stats['总部国家'].isin(country_list)].copy()
    # # 按照country_continent中的国家顺序排序
    # filtered_stats['总部国家'] = pd.Categorical(filtered_stats['总部国家'],categories=country_list,ordered=True)
    # filtered_stats = filtered_stats.sort_values('总部国家')


    # 3. 合并大洲信息
    merged_data = merge_continent_data(country_stats, country_continent)

    # 4. 大洲层面分析
    analysis_results = analyze_by_continent(merged_data)

    # 5. 输出结果
    print("各大洲统计结果:")
    print(analysis_results['continent_stats'].to_string(index=False))

    print("\nKruskal-Wallis检验结果:")
    print(f"H统计量: {analysis_results['kruskal_test']['H']:.2f}")
    print(f"p值: {analysis_results['kruskal_test']['p_value']:.3g}")

    if analysis_results['posthoc'] is not None:
        # 设置显示选项
        pd.set_option('display.max_columns', None)
        pd.set_option('display.width', None)
        pd.set_option('display.max_colwidth', None)

        # 重新打印表格
        print(analysis_results['posthoc'])
        print("\n事后检验结果（Tukey HSD）:")
        print(analysis_results['posthoc'])

    # 6. 可视化
    visualize_results(merged_data, analysis_results)